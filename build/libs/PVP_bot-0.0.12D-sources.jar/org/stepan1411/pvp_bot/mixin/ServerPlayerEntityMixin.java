package org.stepan1411.pvp_bot.mixin;

import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3222.class)
public class ServerPlayerEntityMixin {
    // РџСѓСЃС‚РѕР№ mixin - Р»РѕРіРёРєР° damage РїРµСЂРµРЅРµСЃРµРЅР° РІ Fabric Events
}
