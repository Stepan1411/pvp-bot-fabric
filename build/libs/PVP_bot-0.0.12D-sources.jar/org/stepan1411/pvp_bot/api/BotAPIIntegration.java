package org.stepan1411.pvp_bot.api;

import net.minecraft.class_1297;
import net.minecraft.class_3222;

/**
 * Helper class for integrating API events with the mod's internal systems.
 * This class should be called from BotManager, BotCombat, etc.
 */
public class BotAPIIntegration {
    
    /**
     * Fire spawn event when a bot spawns
     * Call this from BotManager.spawnBot() after adding bot to list
     */
    public static void fireSpawnEvent(class_3222 bot) {
        try {
            PvpBotAPI.getEventManager().fireSpawnEvent(bot);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing spawn event: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Fire death event when a bot dies
     * Call this from BotManager.cleanupDeadBots() before removing bot from list
     */
    public static void fireDeathEvent(class_3222 bot) {
        try {
            PvpBotAPI.getEventManager().fireDeathEvent(bot);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing death event: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Fire attack event when a bot attacks
     * Call this from BotCombat before executing attack
     * @return true if attack should be cancelled
     */
    public static boolean fireAttackEvent(class_3222 bot, class_1297 target) {
        try {
            return PvpBotAPI.getEventManager().fireAttackEvent(bot, target);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing attack event: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Fire damage event when a bot takes damage
     * Call this from damage handler/mixin
     * @return true if damage should be cancelled
     */
    public static boolean fireDamageEvent(class_3222 bot, class_1297 attacker, float damage) {
        try {
            return PvpBotAPI.getEventManager().fireDamageEvent(bot, attacker, damage);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing damage event: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Fire tick event for a bot
     * Call this from BotTicker every tick
     */
    public static void fireTickEvent(class_3222 bot) {
        try {
            PvpBotAPI.getEventManager().fireTickEvent(bot);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing tick event: " + e.getMessage());
            // Don't print stack trace for tick events to avoid spam
        }
    }
}
