package org.stepan1411.pvp_bot.api.event;

import net.minecraft.class_1297;
import net.minecraft.class_3222;

/**
 * Handler for bot damage events
 */
@FunctionalInterface
public interface BotDamageHandler {
    /**
     * Called when a bot receives damage
     * @param bot The bot that received damage
     * @param attacker The attacker entity (can be null)
     * @param damage The damage amount
     * @return true to cancel the damage
     */
    boolean onBotDamage(class_3222 bot, class_1297 attacker, float damage);
}
