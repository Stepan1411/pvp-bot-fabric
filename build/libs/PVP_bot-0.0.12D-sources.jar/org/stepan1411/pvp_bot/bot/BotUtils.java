package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1803;
import net.minecraft.class_1812;
import net.minecraft.class_1828;
import net.minecraft.class_3222;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;

public class BotUtils {
    
    private static final Map<String, BotState> botStates = new HashMap<>();
    
    public static class BotState {
        public int shieldCooldown = 0;
        public int eatCooldown = 0;
        public boolean isBlocking = false;
        public boolean isEating = false;
        public int eatingTicks = 0;
        public int windChargeCooldown = 0;
        public int eatingSlot = -1; // РЎР»РѕС‚ СЃ РµРґРѕР№ РєРѕС‚РѕСЂСѓСЋ РµРґРёРј
        public int potionCooldown = 0; // РљСѓР»РґР°СѓРЅ РЅР° Р·РµР»СЊСЏ
        public int buffPotionCooldown = 0; // РљСѓР»РґР°СѓРЅ РЅР° Р±Р°С„С„РѕРІС‹Рµ Р·РµР»СЊСЏ
        public boolean isThrowingPotion = false; // Р‘СЂРѕСЃР°РµРј Р·РµР»СЊРµ - РЅРµ СЃРјРѕС‚СЂРµС‚СЊ РЅР° С†РµР»СЊ
        public int throwingPotionTicks = 0;
        public boolean isMending = false; // Р§РёРЅРёРјСЃСЏ - РЅРµ СЃРјРѕС‚СЂРµС‚СЊ РЅР° С†РµР»СЊ, СѓР±РµРіР°С‚СЊ
        public int mendingCooldown = 0; // РљСѓР»РґР°СѓРЅ РјРµР¶РґСѓ Р±СЂРѕСЃРєР°РјРё XP Р±СѓС‚С‹Р»РѕРє
        public int xpBottlesThrown = 0; // РЎРєРѕР»СЊРєРѕ Р±СѓС‚С‹Р»РѕРє СѓР¶Рµ Р±СЂРѕСЃРёР»Рё
        public int xpBottlesNeeded = 0; // РЎРєРѕР»СЊРєРѕ Р±СѓС‚С‹Р»РѕРє РЅСѓР¶РЅРѕ Р±СЂРѕСЃРёС‚СЊ
        public java.util.List<Integer> potionsToThrow = new java.util.ArrayList<>(); // РћС‡РµСЂРµРґСЊ Р·РµР»РёР№ РґР»СЏ Р±СЂРѕСЃРєР°
        public class_1799 savedOffhandItem = class_1799.field_8037; // РЎРѕС…СЂР°РЅС‘РЅРЅС‹Р№ РїСЂРµРґРјРµС‚ РёР· offhand (С‚РѕС‚РµРј) РїРµСЂРµРґ Р±Р»РѕРєРёСЂРѕРІРєРѕР№
    }
    
    public static BotState getState(String botName) {
        return botStates.computeIfAbsent(botName, k -> new BotState());
    }
    
    public static void removeState(String botName) {
        botStates.remove(botName);
    }
    
    /**
     * РћР±РЅРѕРІР»РµРЅРёРµ СѓС‚РёР»РёС‚ Р±РѕС‚Р°
     */
    public static void update(class_3222 bot, MinecraftServer server) {
        BotSettings settings = BotSettings.get();
        BotState state = getState(bot.method_5477().getString());
        
        // РЈРјРµРЅСЊС€Р°РµРј РєСѓР»РґР°СѓРЅС‹
        if (state.shieldCooldown > 0) state.shieldCooldown--;
        if (state.eatCooldown > 0) state.eatCooldown--;
        if (state.windChargeCooldown > 0) state.windChargeCooldown--;
        if (state.potionCooldown > 0) state.potionCooldown--;
        if (state.buffPotionCooldown > 0) state.buffPotionCooldown--;
        if (state.mendingCooldown > 0) state.mendingCooldown--;
        
        // РџР РРћР РРўР•Рў 1: РђРІС‚Рѕ-СЂРµРјРѕРЅС‚ Р±СЂРѕРЅРё (РµСЃР»Рё РЅСѓР¶РЅРѕ - РѕС‚СЃС‚СѓРїР°РµРј Рё С‡РёРЅРёРјСЃСЏ)
        if (settings.isAutoMendEnabled()) {
            boolean needsMending = handleAutoMend(bot, state, settings, server);
            if (needsMending) {
                return; // Р§РёРЅРёРјСЃСЏ - РЅРµ РґРµР»Р°РµРј РЅРёС‡РµРіРѕ РґСЂСѓРіРѕРіРѕ
            }
        }
        
        // РћР±СЂР°Р±РѕС‚РєР° Р±СЂРѕСЃРєР° Р·РµР»СЊСЏ - СЃРјРѕС‚СЂРёРј РІРЅРёР· Рё Р±СЂРѕСЃР°РµРј
        if (state.isThrowingPotion) {
            state.throwingPotionTicks++;
            // РџСЂРёРЅСѓРґРёС‚РµР»СЊРЅРѕ СЃРјРѕС‚СЂРёРј РІРЅРёР·
            bot.method_36457(90);
            
            if (state.throwingPotionTicks == 2) {
                // Р‘СЂРѕСЃР°РµРј РЅР° 2-Р№ С‚РёРє
                executeCommand(server, bot, "player " + bot.method_5477().getString() + " use once");
            }
            if (state.throwingPotionTicks >= 5) {
                // РџСЂРѕРІРµСЂСЏРµРј РµСЃС‚СЊ Р»Рё РµС‰С‘ Р·РµР»СЊСЏ РІ РѕС‡РµСЂРµРґРё
                if (!state.potionsToThrow.isEmpty()) {
                    int nextSlot = state.potionsToThrow.remove(0);
                    var inventory = bot.method_31548();
                    
                    // РџРµСЂРµРјРµС‰Р°РµРј РІ С…РѕС‚Р±Р°СЂ РµСЃР»Рё РЅСѓР¶РЅРѕ
                    if (nextSlot >= 9) {
                        class_1799 potion = inventory.method_5438(nextSlot);
                        class_1799 current = inventory.method_5438(8);
                        inventory.method_5447(nextSlot, current);
                        inventory.method_5447(8, potion);
                        nextSlot = 8;
                    }
                    
                    org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, nextSlot);
                    state.throwingPotionTicks = 0; // РЎР±СЂР°СЃС‹РІР°РµРј РґР»СЏ СЃР»РµРґСѓСЋС‰РµРіРѕ Р·РµР»СЊСЏ
                } else {
                    // РћС‡РµСЂРµРґСЊ РїСѓСЃС‚Р° - Р·Р°РєР°РЅС‡РёРІР°РµРј
                    state.isThrowingPotion = false;
                    state.throwingPotionTicks = 0;
                }
            }
            return; // РќРµ РґРµР»Р°РµРј РЅРёС‡РµРіРѕ РґСЂСѓРіРѕРіРѕ РїРѕРєР° Р±СЂРѕСЃР°РµРј
        }
        
        // РџР»Р°РІР°РЅРёРµ
        handleSwimming(bot);
        
        // РђРІС‚Рѕ-С‚РѕС‚РµРј
        if (settings.isAutoTotemEnabled()) {
            handleAutoTotem(bot);
        }
        
        // РђРІС‚Рѕ-Р±Р°С„С„С‹ (Р·РµР»СЊСЏ СЃРёР»С‹, СЃРєРѕСЂРѕСЃС‚Рё, РѕРіРЅРµСЃС‚РѕР№РєРѕСЃС‚Рё) РєРѕРіРґР° РІ Р±РѕСЋ
        if (settings.isAutoPotionEnabled() && !state.isEating) {
            handleAutoBuffPotions(bot, state, server);
        }
        
        // РђРІС‚Рѕ-РµРґР° (РїСЂРёРѕСЂРёС‚РµС‚ РЅР°Рґ С‰РёС‚РѕРј)
        // Р’СЃРµРіРґР° РѕР±СЂР°Р±Р°С‚С‹РІР°РµРј РµСЃР»Рё СѓР¶Рµ РµРґРёРј, РёР»Рё РµСЃР»Рё РЅРµ Р±Р»РѕРєРёСЂСѓРµРј
        if (settings.isAutoEatEnabled() && (state.isEating || !state.isBlocking)) {
            handleAutoEat(bot, state, settings, server);
        }
        
        // РђРІС‚Рѕ-С‰РёС‚ (С‚РѕР»СЊРєРѕ РµСЃР»Рё РЅРµ РµРґРёРј)
        if (settings.isAutoShieldEnabled() && !state.isEating) {
            handleAutoShield(bot, state, settings, server);
        }
    }
    
    /**
     * РџР»Р°РІР°РЅРёРµ - Р±РѕС‚ РїР»С‹РІС‘С‚ РІРІРµСЂС… РєРѕРіРґР° РІ РІРѕРґРµ
     */
    private static void handleSwimming(class_3222 bot) {
        if (bot.method_5799() || bot.method_5869()) {
            bot.method_5796(true);
            
            // РџР»С‹РІС‘Рј РІРІРµСЂС… СЃРёР»СЊРЅРµРµ
            if (bot.method_5869()) {
                bot.method_5762(0, 0.08, 0); // РЎРёР»СЊРЅРµРµ РїР»С‹РІС‘Рј РІРІРµСЂС…
                bot.method_5728(true); // РЎРїСЂРёРЅС‚ РІ РІРѕРґРµ = Р±С‹СЃС‚СЂРѕРµ РїР»Р°РІР°РЅРёРµ
            } else if (bot.method_5799()) {
                bot.method_5762(0, 0.04, 0); // Р”РµСЂР¶РёРјСЃСЏ РЅР° РїРѕРІРµСЂС…РЅРѕСЃС‚Рё
            }
            
            // РџСЂС‹РіР°РµРј РµСЃР»Рё РЅР° РїРѕРІРµСЂС…РЅРѕСЃС‚Рё РІРѕРґС‹
            if (bot.method_24828() && bot.method_5799()) {
                bot.method_6043();
            }
        }
    }
    
    /**
     * РђРІС‚Рѕ-С‚РѕС‚РµРј
     * РќР• Р·Р°РїСѓСЃРєР°РµС‚СЃСЏ РєРѕРіРґР° Р±РѕС‚ Р±Р»РѕРєРёСЂСѓРµС‚ С‰РёС‚РѕРј
     */
    private static void handleAutoTotem(class_3222 bot) {
        BotState state = getState(bot.method_5477().getString());
        
        // РќР• РјРµРЅСЏРµРј offhand РєРѕРіРґР° Р±РѕС‚ Р±Р»РѕРєРёСЂСѓРµС‚ С‰РёС‚РѕРј
        if (state.isBlocking) {
            return;
        }
        
        var inventory = bot.method_31548();
        class_1799 offhand = inventory.method_5438(40);
        
        if (offhand.method_7909() == class_1802.field_8288) return;
        
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8288) {
                inventory.method_5447(i, offhand.method_7972());
                inventory.method_5447(40, stack.method_7972());
                return;
            }
        }
    }
    
    /**
     * РђРІС‚Рѕ-Р±Р°С„С„С‹ - Р·РµР»СЊСЏ СЃРёР»С‹, СЃРєРѕСЂРѕСЃС‚Рё, РѕРіРЅРµСЃС‚РѕР№РєРѕСЃС‚Рё
     * РСЃРїРѕР»СЊР·СѓСЋС‚СЃСЏ РєРѕРіРґР° Р±РѕС‚ РІ Р±РѕСЋ Рё СЌС„С„РµРєС‚ РѕС‚СЃСѓС‚СЃС‚РІСѓРµС‚ РёР»Рё Р·Р°РєР°РЅС‡РёРІР°РµС‚СЃСЏ
     * Р‘СЂРѕСЃР°РµС‚ Р’РЎР• РЅСѓР¶РЅС‹Рµ Р·РµР»СЊСЏ СЃСЂР°Р·Сѓ
     */
    private static void handleAutoBuffPotions(class_3222 bot, BotState state, MinecraftServer server) {
        // РџСЂРѕРІРµСЂСЏРµРј РІ Р±РѕСЋ Р»Рё Р±РѕС‚
        var combatState = BotCombat.getState(bot.method_5477().getString());
        if (combatState.target == null) return; // РќРµ РІ Р±РѕСЋ
        
        if (state.buffPotionCooldown > 0) return; // РљСѓР»РґР°СѓРЅ
        if (state.isThrowingPotion) return; // РЈР¶Рµ Р±СЂРѕСЃР°РµРј
        
        var inventory = bot.method_31548();
        
        // РЎРѕР±РёСЂР°РµРј РІСЃРµ РЅСѓР¶РЅС‹Рµ Р·РµР»СЊСЏ РІ РѕС‡РµСЂРµРґСЊ
        java.util.List<Integer> potionsToUse = new java.util.ArrayList<>();
        
        // РџСЂРѕРІРµСЂСЏРµРј РЅСѓР¶РЅС‹ Р»Рё Р±Р°С„С„С‹ (СЌС„С„РµРєС‚ РѕС‚СЃСѓС‚СЃС‚РІСѓРµС‚ РёР»Рё Р·Р°РєР°РЅС‡РёРІР°РµС‚СЃСЏ < 5 СЃРµРє)
        boolean needStrength = !hasEffect(bot, class_1294.field_5910, 100);
        boolean needSpeed = !hasEffect(bot, class_1294.field_5904, 100);
        boolean needFireResist = !hasEffect(bot, class_1294.field_5918, 100);
        
        if (needStrength) {
            int slot = findSplashBuffPotion(inventory, "strength");
            if (slot >= 0) potionsToUse.add(slot);
        }
        
        if (needSpeed) {
            int slot = findSplashBuffPotion(inventory, "swiftness");
            if (slot < 0) slot = findSplashBuffPotion(inventory, "speed");
            if (slot >= 0) potionsToUse.add(slot);
        }
        
        if (needFireResist) {
            int slot = findSplashBuffPotion(inventory, "fire_resistance");
            if (slot >= 0) potionsToUse.add(slot);
        }
        
        // Р•СЃР»Рё РµСЃС‚СЊ Р·РµР»СЊСЏ РґР»СЏ Р±СЂРѕСЃРєР° - РЅР°С‡РёРЅР°РµРј
        if (!potionsToUse.isEmpty()) {
            // Р‘РµСЂС‘Рј РїРµСЂРІРѕРµ Р·РµР»СЊРµ
            int firstSlot = potionsToUse.remove(0);
            
            // РџРµСЂРµРјРµС‰Р°РµРј РІ С…РѕС‚Р±Р°СЂ РµСЃР»Рё РЅСѓР¶РЅРѕ
            if (firstSlot >= 9) {
                class_1799 potion = inventory.method_5438(firstSlot);
                class_1799 current = inventory.method_5438(8);
                inventory.method_5447(firstSlot, current);
                inventory.method_5447(8, potion);
                firstSlot = 8;
            }
            
            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, firstSlot);
            
            // РЎРѕС…СЂР°РЅСЏРµРј РѕСЃС‚Р°Р»СЊРЅС‹Рµ Р·РµР»СЊСЏ РІ РѕС‡РµСЂРµРґСЊ
            state.potionsToThrow.clear();
            state.potionsToThrow.addAll(potionsToUse);
            
            // РќР°С‡РёРЅР°РµРј Р±СЂРѕСЃРѕРє
            state.isThrowingPotion = true;
            state.throwingPotionTicks = 0;
            state.buffPotionCooldown = 100; // РљСѓР»РґР°СѓРЅ РїРѕСЃР»Рµ РІСЃРµС… Р±Р°С„С„РѕРІ (5 СЃРµРє)
        }
    }
    
    /**
     * РС‰РµС‚ Р’Р—Р Р«Р’РќРћР• Р±Р°С„С„РѕРІРѕРµ Р·РµР»СЊРµ РїРѕ С‚РёРїСѓ (РґР»СЏ Р±СЂРѕСЃРєР° РїРѕРґ СЃРµР±СЏ)
     */
    private static int findSplashBuffPotion(net.minecraft.class_1661 inventory, String effectName) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            class_1792 item = stack.method_7909();
            // РўРѕР»СЊРєРѕ РІР·СЂС‹РІРЅС‹Рµ Р·РµР»СЊСЏ РґР»СЏ Р±СЂРѕСЃРєР°
            if (!(item instanceof class_1828) && !(item instanceof class_1803)) {
                continue;
            }
            
            var potionContents = stack.method_58694(class_9334.field_49651);
            if (potionContents == null) continue;
            
            // РџСЂРѕРІРµСЂСЏРµРј РїРѕ ID Р·РµР»СЊСЏ
            var potion = potionContents.comp_2378();
            if (potion.isPresent()) {
                String potionName = potion.get().method_55840().toLowerCase();
                if (potionName.contains(effectName)) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    /**
     * РџСЂРѕРІРµСЂСЏРµС‚ РµСЃС‚СЊ Р»Рё СЌС„С„РµРєС‚ СЃ РјРёРЅРёРјР°Р»СЊРЅРѕР№ РґР»РёС‚РµР»СЊРЅРѕСЃС‚СЊСЋ
     */
    private static boolean hasEffect(class_3222 bot, net.minecraft.class_6880<net.minecraft.class_1291> effect, int minDuration) {
        var instance = bot.method_6112(effect);
        if (instance == null) return false;
        return instance.method_5584() > minDuration;
    }
    
    /**
     * РС‰РµС‚ Р±Р°С„С„РѕРІРѕРµ Р·РµР»СЊРµ РїРѕ С‚РёРїСѓ
     */
    private static int findBuffPotion(net.minecraft.class_1661 inventory, String effectName) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            class_1792 item = stack.method_7909();
            if (!(item instanceof class_1812) && !(item instanceof class_1828) && !(item instanceof class_1803)) {
                continue;
            }
            
            var potionContents = stack.method_58694(class_9334.field_49651);
            if (potionContents == null) continue;
            
            // РџСЂРѕРІРµСЂСЏРµРј РїРѕ ID Р·РµР»СЊСЏ
            var potion = potionContents.comp_2378();
            if (potion.isPresent()) {
                String potionName = potion.get().method_55840().toLowerCase();
                if (potionName.contains(effectName)) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    /**
     * РСЃРїРѕР»СЊР·СѓРµС‚ Р±Р°С„С„РѕРІРѕРµ Р·РµР»СЊРµ
     */
    private static boolean useBuffPotion(class_3222 bot, BotState state, int slot, MinecraftServer server) {
        var inventory = bot.method_31548();
        class_1799 potionStack = inventory.method_5438(slot);
        class_1792 potionItem = potionStack.method_7909();
        
        // РџРµСЂРµРјРµС‰Р°РµРј РІ С…РѕС‚Р±Р°СЂ РµСЃР»Рё РЅСѓР¶РЅРѕ
        if (slot >= 9) {
            class_1799 current = inventory.method_5438(8);
            inventory.method_5447(slot, current);
            inventory.method_5447(8, potionStack);
            slot = 8;
        }
        
        // РџРµСЂРµРєР»СЋС‡Р°РµРј СЃР»РѕС‚
        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, slot);
        
        if (potionItem instanceof class_1828 || potionItem instanceof class_1803) {
            // Р’Р·СЂС‹РІРЅРѕРµ Р·РµР»СЊРµ - РЅР°С‡РёРЅР°РµРј РїСЂРѕС†РµСЃСЃ Р±СЂРѕСЃРєР° РїРѕРґ СЃРµР±СЏ
            state.isThrowingPotion = true;
            state.throwingPotionTicks = 0;
            state.buffPotionCooldown = 15;
            return true;
        } else if (potionItem instanceof class_1812) {
            // РћР±С‹С‡РЅРѕРµ Р·РµР»СЊРµ - РїСЊС‘Рј
            state.isEating = true;
            state.eatingTicks = 0;
            state.eatingSlot = slot;
            state.buffPotionCooldown = 10;
            bot.method_6019(class_1268.field_5808);
            return true;
        }
        
        return false;
    }
    
    /**
     * РђРІС‚Рѕ-РµРґР° СЃ РёСЃРїРѕР»СЊР·РѕРІР°РЅРёРµРј РєРѕРјР°РЅРґ Carpet
     */
    private static void handleAutoEat(class_3222 bot, BotState state, BotSettings settings, MinecraftServer server) {
        // РџСЂРѕРІРµСЂСЏРµРј РІРєР»СЋС‡РµРЅР° Р»Рё Р°РІС‚Рѕ-РµРґР°
        if (!settings.isAutoEatEnabled()) {
            // Р•СЃР»Рё Р°РІС‚Рѕ-РµРґР° РІС‹РєР»СЋС‡РµРЅР°, РѕСЃС‚Р°РЅР°РІР»РёРІР°РµРј РµРґСѓ РµСЃР»Рё Р±РѕС‚ РµСЃС‚
            if (state.isEating) {
                bot.method_6075();
                state.isEating = false;
                state.eatingTicks = 0;
                state.eatingSlot = -1;
            }
            return;
        }
        
        int hunger = bot.method_7344().method_7586();
        float health = bot.method_6032();
        float maxHealth = bot.method_6063();
        
        boolean needFood = hunger <= settings.getMinHungerToEat();
        boolean needHealth = health <= maxHealth * 0.5f; // РњРµРЅСЊС€Рµ 50% HP
        boolean criticalHealth = health <= maxHealth * 0.3f; // РњРµРЅСЊС€Рµ 30% HP - СЃСЂРѕС‡РЅРѕ РµСЃС‚СЊ!
        
        // РџСЂРѕРІРµСЂСЏРµРј РѕС‚СЃС‚СѓРїР°РµС‚ Р»Рё Р±РѕС‚ (РёР· BotCombat)
        var combatState = BotCombat.getState(bot.method_5477().getString());
        boolean isRetreating = combatState.isRetreating;
        
        if (state.isEating) {
            state.eatingTicks++;
            
            // РџР РРќРЈР”РРўР•Р›Р¬РќРћ РґРµСЂР¶РёРј СЃР»РѕС‚ СЃ РµРґРѕР№
            if (state.eatingSlot >= 0 && state.eatingSlot < 9) {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(bot.method_31548(), state.eatingSlot);
            }
            
            // Р”РµСЂР¶РёРј РџРљРњ РЅР°Р¶Р°С‚С‹Рј РЅР°РїСЂСЏРјСѓСЋ (РЅРµ С‡РµСЂРµР· Carpet - СЌС‚Рѕ РЅРµ СЃР±СЂР°СЃС‹РІР°РµС‚ РїСЂРѕРіСЂРµСЃСЃ)
            class_1799 foodStack = bot.method_6047();
            if (foodStack.method_7909().method_57347().method_58694(class_9334.field_50075) != null) {
                // РСЃРїРѕР»СЊР·СѓРµРј РїСЂРµРґРјРµС‚ РЅР°РїСЂСЏРјСѓСЋ РєР°Р¶РґС‹Р№ С‚РёРє
                bot.method_6019(class_1268.field_5808);
            }
            
            // Р•РґР° Р·Р°РЅРёРјР°РµС‚ ~32 С‚РёРєР°, РЅРѕ СЃ СѓС‡С‘С‚РѕРј Р·Р°РґРµСЂР¶РµРє Р¶РґС‘Рј 80 С‚РёРєРѕРІ (4 СЃРµРє)
            if (state.eatingTicks >= 80) {
                bot.method_6075();
                state.isEating = false;
                state.eatingTicks = 0;
                state.eatingSlot = -1;
                state.eatCooldown = 10;
                
                // Р•СЃР»Рё РІСЃС‘ РµС‰С‘ РЅСѓР¶РЅРѕ РµСЃС‚СЊ - РїСЂРѕРґРѕР»Р¶Р°РµРј СЃСЂР°Р·Сѓ
                hunger = bot.method_7344().method_7586();
                health = bot.method_6032();
                if (health <= maxHealth * 0.5f || hunger < 18) {
                    state.eatCooldown = 0;
                }
            }
            return;
        }
        
        // Р—РѕР»РѕС‚С‹Рµ СЏР±Р»РѕРєРё РјРѕР¶РЅРѕ РµСЃС‚СЊ РїСЂРё Р»СЋР±РѕРј РіРѕР»РѕРґРµ (РѕРЅРё РґР°СЋС‚ СЌС„С„РµРєС‚С‹)
        // Р•РґРёРј РµСЃР»Рё: РєСЂРёС‚РёС‡РµСЃРєРѕРµ HP, РёР»Рё РЅРёР·РєРѕРµ HP (< 50%), РёР»Рё РїСЂРѕСЃС‚Рѕ РіРѕР»РѕРґРЅС‹
        // РќРµ Р¶РґС‘Рј isRetreating - РµРґРёРј СЃСЂР°Р·Сѓ РєРѕРіРґР° РЅСѓР¶РЅРѕ Р»РµС‡РёС‚СЊСЃСЏ
        boolean shouldEat = criticalHealth || needHealth || needFood;
        
        // РўР°РєР¶Рµ РµРґРёРј Р·РѕР»РѕС‚РѕРµ СЏР±Р»РѕРєРѕ РµСЃР»Рё HP < 50% РґР°Р¶Рµ РїСЂРё РїРѕР»РЅРѕРј РіРѕР»РѕРґРµ
        boolean shouldEatGoldenApple = needHealth && hasGoldenApple(bot.method_31548());
        
        if ((shouldEat || shouldEatGoldenApple) && state.eatCooldown <= 0 && !state.isBlocking) {
            int foodSlot = findBestFood(bot.method_31548(), needHealth || criticalHealth);
            if (foodSlot >= 0) {
                var inventory = bot.method_31548();
                
                // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ СЌС‚Рѕ РґРµР№СЃС‚РІРёС‚РµР»СЊРЅРѕ РµРґР°
                class_1799 foodStack = inventory.method_5438(foodSlot);
                if (!foodStack.method_7960() && foodStack.method_7909().method_57347().method_58694(class_9334.field_50075) != null) {
                    // РџРµСЂРµРјРµС‰Р°РµРј РµРґСѓ РІ С…РѕС‚Р±Р°СЂ СЃР»РѕС‚ 8 (РїРѕСЃР»РµРґРЅРёР№)
                    if (foodSlot >= 9) {
                        class_1799 food = inventory.method_5438(foodSlot);
                        class_1799 current = inventory.method_5438(8);
                        inventory.method_5447(foodSlot, current);
                        inventory.method_5447(8, food);
                        foodSlot = 8;
                    }
                    
                    state.eatingSlot = foodSlot;
                    
                    // РџРµСЂРµРєР»СЋС‡Р°РµРј СЃР»РѕС‚ РЅР°РїСЂСЏРјСѓСЋ
                    org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, foodSlot);
                    
                    // РќР°С‡РёРЅР°РµРј РµСЃС‚СЊ РЅР°РїСЂСЏРјСѓСЋ
                    bot.method_6019(class_1268.field_5808);
                    state.isEating = true;
                    state.eatingTicks = 0;
                }
            }
        }
    }
    
    /**
     * РџСЂРѕРІРµСЂСЏРµС‚ РµСЃС‚СЊ Р»Рё Р·РѕР»РѕС‚РѕРµ СЏР±Р»РѕРєРѕ РІ РёРЅРІРµРЅС‚Р°СЂРµ
     */
    private static boolean hasGoldenApple(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1792 item = inventory.method_5438(i).method_7909();
            if (item == class_1802.field_8463 || item == class_1802.field_8367) {
                return true;
            }
        }
        return false;
    }

    
    private static int findBestFood(net.minecraft.class_1661 inventory, boolean preferGoldenApple) {
        int bestSlot = -1;
        int bestValue = 0;
        
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            int value = getFoodValue(stack.method_7909(), preferGoldenApple);
            if (value > bestValue) {
                bestValue = value;
                bestSlot = i;
            }
        }
        return bestSlot;
    }
    
    private static int getFoodValue(class_1792 item, boolean preferGoldenApple) {
        if (preferGoldenApple) {
            if (item == class_1802.field_8367) return 100;
            if (item == class_1802.field_8463) return 90;
        }
        if (item == class_1802.field_8071) return 80;
        if (item == class_1802.field_8176) return 70;
        if (item == class_1802.field_8261) return 70;
        if (item == class_1802.field_8347) return 65;
        if (item == class_1802.field_8509) return 60;
        if (item == class_1802.field_8373) return 55;
        if (item == class_1802.field_8544) return 50;
        if (item == class_1802.field_8229) return 45;
        if (item == class_1802.field_8512) return 45;
        if (item == class_1802.field_8279) return 30;
        if (item == class_1802.field_8179) return 25;
        
        var foodComponent = item.method_57347().method_58694(class_9334.field_50075);
        if (foodComponent != null) {
            return foodComponent.comp_2491() * 5;
        }
        return 0;
    }
    
    /**
     * РђРІС‚Рѕ-С‰РёС‚ - Р±Р»РѕРєРёСЂСѓРµС‚ С‚РѕР»СЊРєРѕ РєРѕРіРґР° РІСЂР°Рі РѕС‡РµРЅСЊ Р±Р»РёР·РєРѕ Рё Р°С‚Р°РєСѓРµС‚
     * РЈС‡РёС‚С‹РІР°РµС‚ РїСЂРёРѕСЂРёС‚РµС‚ С‚РѕС‚РµРјР°
     */
    private static void handleAutoShield(class_3222 bot, BotState state, BotSettings settings, MinecraftServer server) {
        var inventory = bot.method_31548();
        int shieldSlot = findShield(inventory);
        if (shieldSlot < 0) {
            state.isBlocking = false;
            return;
        }
        
        // Р•СЃР»Рё РІРєР»СЋС‡РµРЅ РїСЂРёРѕСЂРёС‚РµС‚ С‚РѕС‚РµРјР° - РЅРµ Р·Р°РјРµРЅСЏРµРј С‚РѕС‚РµРј РЅР° С‰РёС‚
        if (settings.isTotemPriority()) {
            class_1799 offhand = inventory.method_5438(40);
            if (offhand.method_7909() == class_1802.field_8288) {
                // РўРѕС‚РµРј РІ offhand - РЅРµ Р±Р»РѕРєРёСЂСѓРµРј
                if (state.isBlocking) {
                    stopBlocking(bot, state, server);
                }
                return;
            }
        }
        
        var combatState = BotCombat.getState(bot.method_5477().getString());
        var target = combatState.target;
        
        if (target == null || state.shieldCooldown > 0) {
            if (state.isBlocking) {
                stopBlocking(bot, state, server);
            }
            return;
        }
        
        double distance = bot.method_5739(target);
        boolean isRetreating = combatState.isRetreating;
        float health = bot.method_6032();
        float maxHealth = bot.method_6063();
        boolean lowHealth = health <= maxHealth * 0.3f;
        
        // Р‘Р»РѕРєРёСЂСѓРµРј РµСЃР»Рё:
        // 1. Р’СЂР°Рі Р±Р»РёР·РєРѕ Рё Р°С‚Р°РєСѓРµС‚
        // 2. РћС‚СЃС‚СѓРїР°РµРј СЃ РЅРёР·РєРёРј HP
        boolean shouldBlock = false;
        
        if (distance <= 4.0) {
            // Р‘Р»РѕРєРёСЂСѓРµРј РµСЃР»Рё РІСЂР°Рі Р°С‚Р°РєСѓРµС‚
            if (target instanceof class_1657 player && player.field_6252) {
                shouldBlock = true;
            }
            // РР»Рё РµСЃР»Рё РѕС‚СЃС‚СѓРїР°РµРј СЃ РЅРёР·РєРёРј HP
            if (isRetreating && lowHealth) {
                shouldBlock = true;
            }
        }
        
        // РќРµ Р±Р»РѕРєРёСЂСѓРµРј РµСЃР»Рё РµРґРёРј
        if (state.isEating) {
            shouldBlock = false;
        }
        
        if (shouldBlock && !state.isBlocking) {
            startBlocking(bot, state, shieldSlot, server);
            state.shieldCooldown = 30; // Р‘Р»РѕРєРёСЂСѓРµРј РјР°РєСЃРёРјСѓРј 1.5 СЃРµРєСѓРЅРґС‹
        } else if (!shouldBlock && state.isBlocking) {
            stopBlocking(bot, state, server);
        }
    }
    
    private static void startBlocking(class_3222 bot, BotState state, int shieldSlot, MinecraftServer server) {
        var inventory = bot.method_31548();
        
        if (shieldSlot != 40) {
            class_1799 shield = inventory.method_5438(shieldSlot);
            class_1799 offhand = inventory.method_5438(40);
            
            // РЎРѕС…СЂР°РЅСЏРµРј С‡С‚Рѕ Р±С‹Р»Рѕ РІ offhand (РѕР±С‹С‡РЅРѕ С‚РѕС‚РµРј)
            state.savedOffhandItem = offhand.method_7972();
            
            // РњРµРЅСЏРµРј РјРµСЃС‚Р°РјРё С‰РёС‚ Рё offhand
            inventory.method_5447(shieldSlot, offhand);
            inventory.method_5447(40, shield);
        }
        
        // Р‘Р»РѕРєРёСЂСѓРµРј С‡РµСЂРµР· Carpet
        executeCommand(server, bot, "player " + bot.method_5477().getString() + " use continuous");
        state.isBlocking = true;
    }
    
    private static void stopBlocking(class_3222 bot, BotState state, MinecraftServer server) {
        executeCommand(server, bot, "player " + bot.method_5477().getString() + " stop");
        state.isBlocking = false;
        
        var inventory = bot.method_31548();
        class_1799 currentOffhand = inventory.method_5438(40);
        
        // Р•СЃР»Рё РІ offhand С‰РёС‚ Рё Сѓ РЅР°СЃ РµСЃС‚СЊ СЃРѕС…СЂР°РЅС‘РЅРЅС‹Р№ РїСЂРµРґРјРµС‚ (С‚РѕС‚РµРј)
        if (currentOffhand.method_7909() == class_1802.field_8255 && !state.savedOffhandItem.method_7960()) {
            // РС‰РµРј СЃРІРѕР±РѕРґРЅС‹Р№ СЃР»РѕС‚ РґР»СЏ С‰РёС‚Р°
            int emptySlot = -1;
            for (int i = 0; i < 36; i++) {
                if (inventory.method_5438(i).method_7960()) {
                    emptySlot = i;
                    break;
                }
            }
            
            if (emptySlot >= 0) {
                // Р’РѕР·РІСЂР°С‰Р°РµРј С‰РёС‚ РІ РёРЅРІРµРЅС‚Р°СЂСЊ
                inventory.method_5447(emptySlot, currentOffhand.method_7972());
                // Р’РѕР·РІСЂР°С‰Р°РµРј СЃРѕС…СЂР°РЅС‘РЅРЅС‹Р№ РїСЂРµРґРјРµС‚ (С‚РѕС‚РµРј) РІ offhand
                inventory.method_5447(40, state.savedOffhandItem.method_7972());
            }
            
            // РћС‡РёС‰Р°РµРј СЃРѕС…СЂР°РЅС‘РЅРЅС‹Р№ РїСЂРµРґРјРµС‚
            state.savedOffhandItem = class_1799.field_8037;
        }
    }
    
    private static int findShield(net.minecraft.class_1661 inventory) {
        if (inventory.method_5438(40).method_7909() == class_1802.field_8255) return 40;
        for (int i = 0; i < 36; i++) {
            if (inventory.method_5438(i).method_7909() == class_1802.field_8255) return i;
        }
        return -1;
    }
    
    /**
     * РСЃРїРѕР»СЊР·РѕРІР°С‚СЊ Wind Charge С‡РµСЂРµР· РєРѕРјР°РЅРґСѓ Carpet
     */
    public static void useWindCharge(class_3222 bot, MinecraftServer server) {
        BotState state = getState(bot.method_5477().getString());
        if (state.windChargeCooldown > 0) return;
        if (state.isEating) return; // РќРµ РїСЂРµСЂС‹РІР°РµРј РµРґСѓ
        
        var inventory = bot.method_31548();
        int slot = findWindCharge(inventory);
        if (slot < 0) return;
        
        // РџРµСЂРµРјРµС‰Р°РµРј РІ С…РѕС‚Р±Р°СЂ
        if (slot >= 9) {
            class_1799 wc = inventory.method_5438(slot);
            class_1799 current = inventory.method_5438(0);
            inventory.method_5447(slot, current);
            inventory.method_5447(0, wc);
            slot = 0;
        }
        
        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, slot);
        
        // РЎРјРѕС‚СЂРёРј РІРЅРёР·
        bot.method_36457(90);
        
        // РСЃРїРѕР»СЊР·СѓРµРј С‡РµСЂРµР· Carpet
        executeCommand(server, bot, "player " + bot.method_5477().getString() + " use once");
        
        state.windChargeCooldown = 20; // 1 СЃРµРєСѓРЅРґР° РєСѓР»РґР°СѓРЅ
    }
    
    private static int findWindCharge(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            if (inventory.method_5438(i).method_7909() == class_1802.field_49098) return i;
        }
        return -1;
    }
    
    /**
     * РЎР±РёС‚СЊ С‰РёС‚ С‚РѕРїРѕСЂРѕРј
     */
    public static boolean tryDisableShield(class_3222 bot, class_1297 target) {
        // РќРµ РїСЂРµСЂС‹РІР°РµРј РµРґСѓ
        BotState state = getState(bot.method_5477().getString());
        if (state.isEating) return false;
        
        if (!(target instanceof class_1657 player)) return false;
        if (!player.method_6039()) return false;
        
        var inventory = bot.method_31548();
        int axeSlot = findAxe(inventory);
        if (axeSlot < 0) return false;
        
        if (axeSlot >= 9) {
            class_1799 axe = inventory.method_5438(axeSlot);
            class_1799 current = inventory.method_5438(0);
            inventory.method_5447(axeSlot, current);
            inventory.method_5447(0, axe);
            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
        } else {
            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, axeSlot);
        }
        return true;
    }
    
    private static int findAxe(net.minecraft.class_1661 inventory) {
        int[] priorities = {-1, -1, -1, -1, -1, -1};
        for (int i = 0; i < 36; i++) {
            class_1792 item = inventory.method_5438(i).method_7909();
            if (item == class_1802.field_22025) priorities[0] = i;
            else if (item == class_1802.field_8556) priorities[1] = i;
            else if (item == class_1802.field_8475) priorities[2] = i;
            else if (item == class_1802.field_8062) priorities[3] = i;
            else if (item == class_1802.field_8825) priorities[4] = i;
            else if (item == class_1802.field_8406) priorities[5] = i;
        }
        for (int slot : priorities) {
            if (slot >= 0) return slot;
        }
        return -1;
    }
    
    /**
     * Р’С‹РїРѕР»РЅРёС‚СЊ РєРѕРјР°РЅРґСѓ Carpet
     */
    private static void executeCommand(MinecraftServer server, class_3222 bot, String command) {
        try {
            server.method_3734().method_9235().execute(command, server.method_3739());
        } catch (Exception e) {
            // РРіРЅРѕСЂРёСЂСѓРµРј РѕС€РёР±РєРё
        }
    }
    
    /**
     * РџСЂРѕРІРµСЂСЏРµС‚ РµСЃС‚СЊ Р»Рё РµРґР° РІ РёРЅРІРµРЅС‚Р°СЂРµ
     */
    public static boolean hasFood(class_3222 bot) {
        var inventory = bot.method_31548();
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960()) {
                var foodComponent = stack.method_7909().method_57347().method_58694(class_9334.field_50075);
                if (foodComponent != null) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * РџСЂРѕР±СѓРµС‚ РёСЃРїРѕР»СЊР·РѕРІР°С‚СЊ Р·РµР»СЊРµ РёСЃС†РµР»РµРЅРёСЏ
     * Р’РѕР·РІСЂР°С‰Р°РµС‚ true РµСЃР»Рё РЅР°С‡Р°Р» РїРёС‚СЊ/Р±СЂРѕСЃРёР» Р·РµР»СЊРµ
     */
    public static boolean tryUseHealingPotion(class_3222 bot, MinecraftServer server) {
        BotState state = getState(bot.method_5477().getString());
        if (state.isEating) return false; // РЈР¶Рµ С‡С‚Рѕ-С‚Рѕ РґРµР»Р°РµРј
        if (state.potionCooldown > 0) return false; // РљСѓР»РґР°СѓРЅ РЅР° Р·РµР»СЊСЏ
        
        var inventory = bot.method_31548();
        
        // РС‰РµРј Р·РµР»СЊРµ РёСЃС†РµР»РµРЅРёСЏ (РѕР±С‹С‡РЅРѕРµ РёР»Рё РІР·СЂС‹РІРЅРѕРµ)
        int potionSlot = findHealingPotion(inventory);
        if (potionSlot < 0) return false;
        
        class_1799 potionStack = inventory.method_5438(potionSlot);
        class_1792 potionItem = potionStack.method_7909();
        
        // РџРµСЂРµРјРµС‰Р°РµРј РІ С…РѕС‚Р±Р°СЂ РµСЃР»Рё РЅСѓР¶РЅРѕ
        if (potionSlot >= 9) {
            class_1799 current = inventory.method_5438(8);
            inventory.method_5447(potionSlot, current);
            inventory.method_5447(8, potionStack);
            potionSlot = 8;
        }
        
        // РџРµСЂРµРєР»СЋС‡Р°РµРј СЃР»РѕС‚
        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, potionSlot);
        
        if (potionItem instanceof class_1828 || potionItem instanceof class_1803) {
            // Р’Р·СЂС‹РІРЅРѕРµ Р·РµР»СЊРµ - РЅР°С‡РёРЅР°РµРј РїСЂРѕС†РµСЃСЃ Р±СЂРѕСЃРєР° РїРѕРґ СЃРµР±СЏ
            state.isThrowingPotion = true;
            state.throwingPotionTicks = 0;
            state.potionCooldown = 10;
            return true;
        } else if (potionItem instanceof class_1812) {
            // РћР±С‹С‡РЅРѕРµ Р·РµР»СЊРµ - РїСЊС‘Рј
            state.isEating = true;
            state.eatingTicks = 0;
            state.eatingSlot = potionSlot;
            state.potionCooldown = 5; // 5 С‚РёРєРѕРІ РїРѕСЃР»Рµ РїРёС‚СЊСЏ
            bot.method_6019(class_1268.field_5808);
            return true;
        }
        
        return false;
    }
    
    /**
     * РС‰РµС‚ Р·РµР»СЊРµ РёСЃС†РµР»РµРЅРёСЏ РІ РёРЅРІРµРЅС‚Р°СЂРµ
     */
    private static int findHealingPotion(net.minecraft.class_1661 inventory) {
        // РџСЂРёРѕСЂРёС‚РµС‚: РІР·СЂС‹РІРЅРѕРµ > РѕР±С‹С‡РЅРѕРµ
        int splashSlot = -1;
        int normalSlot = -1;
        
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            class_1792 item = stack.method_7909();
            
            // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ СЌС‚Рѕ Р·РµР»СЊРµ РёСЃС†РµР»РµРЅРёСЏ
            if (isHealingPotion(stack)) {
                if (item instanceof class_1828 || item instanceof class_1803) {
                    if (splashSlot < 0) splashSlot = i;
                } else if (item instanceof class_1812) {
                    if (normalSlot < 0) normalSlot = i;
                }
            }
        }
        
        // РџСЂРµРґРїРѕС‡РёС‚Р°РµРј РІР·СЂС‹РІРЅРѕРµ (Р±С‹СЃС‚СЂРµРµ)
        return splashSlot >= 0 ? splashSlot : normalSlot;
    }
    
    /**
     * РџСЂРѕРІРµСЂСЏРµС‚ СЏРІР»СЏРµС‚СЃСЏ Р»Рё Р·РµР»СЊРµ Р·РµР»СЊРµРј РёСЃС†РµР»РµРЅРёСЏ
     */
    private static boolean isHealingPotion(class_1799 stack) {
        var potionContents = stack.method_58694(class_9334.field_49651);
        if (potionContents == null) return false;
        
        // РџСЂРѕРІРµСЂСЏРµРј СЌС„С„РµРєС‚С‹ Р·РµР»СЊСЏ
        for (var effect : potionContents.method_57397()) {
            var effectType = effect.method_5579().comp_349();
            String effectName = effectType.toString().toLowerCase();
            if (effectName.contains("healing") || effectName.contains("instant_health")) {
                return true;
            }
        }
        
        // РўР°РєР¶Рµ РїСЂРѕРІРµСЂСЏРµРј РїРѕ ID Р·РµР»СЊСЏ
        var potion = potionContents.comp_2378();
        if (potion.isPresent()) {
            String potionName = potion.get().method_55840().toLowerCase();
            if (potionName.contains("healing") || potionName.contains("health")) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * РђРІС‚Рѕ-СЂРµРјРѕРЅС‚ Р±СЂРѕРЅРё СЃ Mending С‡РµСЂРµР· XP Р±СѓС‚С‹Р»РєРё
     * РџСЂРѕРІРµСЂСЏРµС‚ РїСЂРѕС‡РЅРѕСЃС‚СЊ Р±СЂРѕРЅРё Рё РёСЃРїРѕР»СЊР·СѓРµС‚ XP Р±СѓС‚С‹Р»РєРё РєРѕРіРґР° РЅСѓР¶РЅРѕ
     * Р’РѕР·РІСЂР°С‰Р°РµС‚ true РµСЃР»Рё Р±РѕС‚ С‡РёРЅРёС‚СЃСЏ (РЅСѓР¶РЅРѕ РѕС‚СЃС‚СѓРїР°С‚СЊ)
     */
    private static boolean handleAutoMend(class_3222 bot, BotState state, BotSettings settings, MinecraftServer server) {
        var inventory = bot.method_31548();
        
        // РџСЂРѕРІРµСЂСЏРµРј РµСЃС‚СЊ Р»Рё XP Р±СѓС‚С‹Р»РєРё
        int xpBottleSlot = findXpBottle(inventory);
        if (xpBottleSlot < 0) {
            state.isMending = false;
            state.xpBottlesThrown = 0;
            state.xpBottlesNeeded = 0;
            return false; // РќРµС‚ XP Р±СѓС‚С‹Р»РѕРє
        }
        
        // РџСЂРѕРІРµСЂСЏРµРј РєР°Р¶РґС‹Р№ СЃР»РѕС‚ Р±СЂРѕРЅРё Рё СЃС‡РёС‚Р°РµРј СЃРєРѕР»СЊРєРѕ СѓСЂРѕРЅР° РЅСѓР¶РЅРѕ РїРѕС‡РёРЅРёС‚СЊ
        int totalDamageToRepair = 0;
        int itemsNeedingRepair = 0;
        
        for (int armorSlot = 36; armorSlot < 40; armorSlot++) {
            class_1799 armorPiece = inventory.method_5438(armorSlot);
            if (armorPiece.method_7960()) continue;
            
            // РџСЂРѕРІРµСЂСЏРµРј РµСЃС‚СЊ Р»Рё Mending РЅР° Р±СЂРѕРЅРµ
            if (!hasMendingEnchantment(armorPiece)) continue;
            
            // РџСЂРѕРІРµСЂСЏРµРј РїСЂРѕС‡РЅРѕСЃС‚СЊ
            int maxDamage = armorPiece.method_7936();
            int currentDamage = armorPiece.method_7919();
            double durabilityPercent = 1.0 - ((double) currentDamage / maxDamage);
            
            // Р•СЃР»Рё РїСЂРѕС‡РЅРѕСЃС‚СЊ РЅРёР¶Рµ РїРѕСЂРѕРіР° - РЅСѓР¶РµРЅ СЂРµРјРѕРЅС‚
            if (durabilityPercent < settings.getMendDurabilityThreshold()) {
                // РЎС‡РёС‚Р°РµРј СЃРєРѕР»СЊРєРѕ РЅСѓР¶РЅРѕ РїРѕС‡РёРЅРёС‚СЊ РґРѕ 90%
                int targetDamage = (int) (maxDamage * 0.1); // 90% = 10% СѓСЂРѕРЅР°
                int damageToRepair = currentDamage - targetDamage;
                if (damageToRepair > 0) {
                    totalDamageToRepair += damageToRepair;
                    itemsNeedingRepair++;
                }
            }
        }
        
        if (totalDamageToRepair <= 0) {
            // Р’СЃСЏ Р±СЂРѕРЅСЏ РїРѕС‡РёРЅРµРЅР°!
            state.isMending = false;
            state.xpBottlesThrown = 0;
            state.xpBottlesNeeded = 0;
            return false;
        }
        
        // Р•СЃР»Рё С‚РѕР»СЊРєРѕ РЅР°С‡РёРЅР°РµРј С‡РёРЅРёС‚СЊСЃСЏ - СЂР°СЃСЃС‡РёС‚С‹РІР°РµРј СЃРєРѕР»СЊРєРѕ Р±СѓС‚С‹Р»РѕРє РЅСѓР¶РЅРѕ РћР”РРќ Р РђР—
        if (!state.isMending) {
            // Р РµР°Р»СЊРЅС‹Рµ РґР°РЅРЅС‹Рµ: РЅРµР·РµСЂРёС‚РѕРІС‹Р№ РЅР°РіСЂСѓРґРЅРёРє 0в†’95% = ~20 Р±СѓС‚С‹Р»РѕРє РґР»СЏ ~562 СѓСЂРѕРЅР°
            // Р­С‚Рѕ Р·РЅР°С‡РёС‚ ~28 СѓСЂРѕРЅР° РЅР° Р±СѓС‚С‹Р»РєСѓ
            // Р¤РѕСЂРјСѓР»Р°: totalDamageToRepair / 28
            state.xpBottlesNeeded = (totalDamageToRepair / 28) + 2; // +2 РґР»СЏ Р·Р°РїР°СЃР°
            if (state.xpBottlesNeeded < 5) state.xpBottlesNeeded = 5; // РњРёРЅРёРјСѓРј 5 Р±СѓС‚С‹Р»РѕРє
            state.xpBottlesThrown = 0;
        }
        
        // Р‘Р РћРќРЇ РЎР›РћРњРђРќРђ - РћРўРЎРўРЈРџРђР•Рњ Р Р§РРќРРњРЎРЇ!
        state.isMending = true;
        
        // РџРѕР»СѓС‡Р°РµРј С†РµР»СЊ РёР· BotCombat
        var combatState = BotCombat.getState(bot.method_5477().getString());
        class_1297 target = combatState.target;
        
        // РћС‚СЃС‚СѓРїР°РµРј РѕС‚ РІСЂР°РіР° РµСЃР»Рё РѕРЅ РµСЃС‚СЊ (СЃРєРѕСЂРѕСЃС‚СЊ 1.3 = Р±С‹СЃС‚СЂРѕ!)
        if (target != null) {
            BotNavigation.lookAway(bot, target);
            BotNavigation.moveAway(bot, target, 1.3); // 1.3 = Р±С‹СЃС‚СЂРѕ СЃ bhop!
        }
        
        // РџСЂРѕРІРµСЂСЏРµРј Р±СЂРѕСЃРёР»Рё Р»Рё СѓР¶Рµ РґРѕСЃС‚Р°С‚РѕС‡РЅРѕ Р±СѓС‚С‹Р»РѕРє
        if (state.xpBottlesThrown >= state.xpBottlesNeeded) {
            // Р—Р°РєРѕРЅС‡РёР»Рё Р±СЂРѕСЃР°С‚СЊ - РІС‹С…РѕРґРёРј РёР· СЂРµР¶РёРјР° РїРѕС‡РёРЅРєРё
            state.isMending = false;
            state.xpBottlesThrown = 0;
            state.xpBottlesNeeded = 0;
            return false;
        }
        
        // РџРµСЂРµРјРµС‰Р°РµРј XP Р±СѓС‚С‹Р»РєСѓ РІ С…РѕС‚Р±Р°СЂ РµСЃР»Рё РЅСѓР¶РЅРѕ
        if (xpBottleSlot >= 9) {
            class_1799 xpBottle = inventory.method_5438(xpBottleSlot);
            class_1799 current = inventory.method_5438(8);
            inventory.method_5447(xpBottleSlot, current);
            inventory.method_5447(8, xpBottle);
            xpBottleSlot = 8;
        }
        
        // РџРµСЂРµРєР»СЋС‡Р°РµРј СЃР»РѕС‚ РЅР° XP Р±СѓС‚С‹Р»РєСѓ
        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, xpBottleSlot);
        
        // РЎРјРѕС‚СЂРёРј РјР°РєСЃРёРјР°Р»СЊРЅРѕ РІРЅРёР·
        bot.method_36457(90);
        
        // РљРР”РђР•Рњ Р‘РЈРўР«Р›РљРЈ РљРђР–Р”Р«Р™ РўРРљ!
        executeCommand(server, bot, "player " + bot.method_5477().getString() + " use once");
        
        state.xpBottlesThrown++;
        
        return true; // Р’РѕР·РІСЂР°С‰Р°РµРј true - Р±РѕС‚ С‡РёРЅРёС‚СЃСЏ
    }
    
    /**
     * РџСЂРѕРІРµСЂСЏРµС‚ РµСЃС‚СЊ Р»Рё Р·Р°С‡Р°СЂРѕРІР°РЅРёРµ Mending РЅР° РїСЂРµРґРјРµС‚Рµ
     */
    private static boolean hasMendingEnchantment(class_1799 stack) {
        var enchantments = stack.method_58694(class_9334.field_49633);
        if (enchantments == null) return false;
        
        // РџСЂРѕРІРµСЂСЏРµРј РІСЃРµ Р·Р°С‡Р°СЂРѕРІР°РЅРёСЏ
        for (var entry : enchantments.method_57534()) {
            String enchantName = entry.method_55840().toLowerCase();
            if (enchantName.contains("mending")) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * РС‰РµС‚ XP Р±СѓС‚С‹Р»РєСѓ РІ РёРЅРІРµРЅС‚Р°СЂРµ
     */
    private static int findXpBottle(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            if (inventory.method_5438(i).method_7909() == class_1802.field_8287) {
                return i;
            }
        }
        return -1;
    }
}
