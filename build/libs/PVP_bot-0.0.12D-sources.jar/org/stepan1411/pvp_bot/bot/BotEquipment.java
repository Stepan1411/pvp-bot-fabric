package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1304;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;
import net.minecraft.item.*;
import java.util.ArrayList;
import java.util.List;

public class BotEquipment {

    public static void autoEquip(class_3222 bot) {
        // РќР• СЌРєРёРїРёСЂСѓРµРј РѕСЂСѓР¶РёРµ РµСЃР»Рё Р±РѕС‚ РµСЃС‚!
        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (utilsState.isEating) {
            return;
        }
        
        BotSettings settings = BotSettings.get();
        
        if (settings.isAutoEquipArmor()) {
            equipBestArmor(bot);
        }
        if (settings.isAutoEquipWeapon()) {
            equipBestWeapon(bot);
        }
    }

    private static void equipBestArmor(class_3222 bot) {
        equipBestForSlot(bot, class_1304.field_6169);
        equipBestForSlot(bot, class_1304.field_6174);
        equipBestForSlot(bot, class_1304.field_6172);
        equipBestForSlot(bot, class_1304.field_6166);
    }

    private static void equipBestForSlot(class_3222 bot, class_1304 slot) {
        BotSettings settings = BotSettings.get();
        var inventory = bot.method_31548();
        
        // РЁР°Рі 1: РќР°Р№С‚Рё Р»СѓС‡С€СѓСЋ Р±СЂРѕРЅСЋ РґР»СЏ СЌС‚РѕРіРѕ СЃР»РѕС‚Р° (РІРєР»СЋС‡Р°СЏ С‚РµРєСѓС‰СѓСЋ СЌРєРёРїРёСЂРѕРІР°РЅРЅСѓСЋ)
        class_1799 currentArmor = bot.method_6118(slot);
        double currentValue = getArmorValue(currentArmor, slot);
        
        int bestInvSlot = -1;
        double bestValue = currentValue;
        
        // РС‰РµРј Р»СѓС‡С€СѓСЋ Р±СЂРѕРЅСЋ РІ РёРЅРІРµРЅС‚Р°СЂРµ
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            if (!isArmorForSlot(stack.method_7909(), slot)) continue;
            
            double value = getArmorValue(stack, slot);
            if (value > bestValue) {
                bestValue = value;
                bestInvSlot = i;
            }
        }
        
        // РЁР°Рі 2: Р­РєРёРїРёСЂСѓРµРј Р»СѓС‡С€СѓСЋ Р±СЂРѕРЅСЋ РµСЃР»Рё РѕРЅР° РІ РёРЅРІРµРЅС‚Р°СЂРµ
        if (bestInvSlot >= 0) {
            class_1799 newArmor = inventory.method_5438(bestInvSlot).method_7972();
            class_1799 oldArmor = currentArmor.method_7972();
            
            // РќР°РґРµРІР°РµРј РЅРѕРІСѓСЋ Р±СЂРѕРЅСЋ
            bot.method_5673(slot, newArmor);
            inventory.method_5447(bestInvSlot, class_1799.field_8037);
            
            // РЎС‚Р°СЂСѓСЋ Р±СЂРѕРЅСЋ РєР»Р°РґС‘Рј РІ РёРЅРІРµРЅС‚Р°СЂСЊ (РµСЃР»Рё Р±С‹Р»Р°)
            if (!oldArmor.method_7960()) {
                inventory.method_5447(bestInvSlot, oldArmor);
            }
            
            currentArmor = newArmor;
            currentValue = bestValue;
        }

        
        // РЁР°Рі 3: Р’С‹Р±СЂР°СЃС‹РІР°РµРј С…СѓРґС€СѓСЋ Р±СЂРѕРЅСЋ (С‚РѕР»СЊРєРѕ РµСЃР»Рё РІРєР»СЋС‡РµРЅРѕ)
        if (settings.isDropWorseArmor()) {
            for (int i = 0; i < inventory.method_5439(); i++) {
                class_1799 stack = inventory.method_5438(i);
                if (stack.method_7960()) continue;
                if (!isArmorForSlot(stack.method_7909(), slot)) continue;
                
                double value = getArmorValue(stack, slot);
                
                // Р’С‹Р±СЂР°СЃС‹РІР°РµРј С‚РѕР»СЊРєРѕ РµСЃР»Рё С…СѓР¶Рµ С‚РµРєСѓС‰РµР№ СЌРєРёРїРёСЂРѕРІР°РЅРЅРѕР№
                if (value < currentValue) {
                    dropItemBackward(bot, stack);
                    inventory.method_5447(i, class_1799.field_8037);
                }
            }
        }
    }

    /**
     * Р’С‹Р±СЂР°СЃС‹РІР°РµС‚ РїСЂРµРґРјРµС‚ РЅР°Р·Р°Рґ РёР»Рё РІР±РѕРє РѕС‚ Р±РѕС‚Р° (РєР°Рє РЅР°Р¶Р°С‚РёРµ Q СЃ РїРѕРІРѕСЂРѕС‚РѕРј)
     */
    private static void dropItemBackward(class_3222 bot, class_1799 stack) {
        if (stack.method_7960()) return;
        
        BotSettings settings = BotSettings.get();
        double distance = settings.getDropDistance();
        
        // РЎРѕС…СЂР°РЅСЏРµРј С‚РµРєСѓС‰РёР№ СѓРіРѕР»
        float oldYaw = bot.method_36454();
        float oldHeadYaw = bot.method_5791();
        
        // РџРѕРІРѕСЂР°С‡РёРІР°РµРј РЅР°Р·Р°Рґ РёР»Рё РІР±РѕРє (90-270 РіСЂР°РґСѓСЃРѕРІ РѕС‚ С‚РµРєСѓС‰РµРіРѕ РЅР°РїСЂР°РІР»РµРЅРёСЏ)
        float turnAngle = 90 + (float)(Math.random() * 180); // РѕС‚ 90 РґРѕ 270 РіСЂР°РґСѓСЃРѕРІ
        float newYaw = oldYaw + turnAngle;
        
        bot.method_36456(newYaw);
        bot.method_5847(newYaw);
        
        // Р’С‹Р±СЂР°СЃС‹РІР°РµРј РєР°Рє РїСЂРё РЅР°Р¶Р°С‚РёРё Q (throwRandomly=false, retainOwnership=true)
        class_1542 dropped = bot.method_7329(stack.method_7972(), false, true);
        
        if (dropped != null) {
            // РЎРєРѕСЂРѕСЃС‚СЊ РІ РЅР°РїСЂР°РІР»РµРЅРёРё РІР·РіР»СЏРґР°
            double yawRad = Math.toRadians(newYaw);
            double speed = 0.3 * distance;
            dropped.method_18800(
                -Math.sin(yawRad) * speed,
                0.2,
                Math.cos(yawRad) * speed
            );
            dropped.method_6982(60); // 3 СЃРµРєСѓРЅРґС‹ Р·Р°РґРµСЂР¶РєРё
        }
        
        // Р’РѕР·РІСЂР°С‰Р°РµРј СѓРіРѕР» РѕР±СЂР°С‚РЅРѕ
        bot.method_36456(oldYaw);
        bot.method_5847(oldHeadYaw);
    }

    private static boolean isArmorForSlot(class_1792 item, class_1304 slot) {
        return switch (slot) {
            case field_6169 -> item == class_1802.field_22027 || item == class_1802.field_8805 ||
                         item == class_1802.field_8743 || item == class_1802.field_8283 ||
                         item == class_1802.field_8862 || item == class_1802.field_8267 ||
                         item == class_1802.field_8090;
            case field_6174 -> item == class_1802.field_22028 || item == class_1802.field_8058 ||
                          item == class_1802.field_8523 || item == class_1802.field_8873 ||
                          item == class_1802.field_8678 || item == class_1802.field_8577 ||
                          item == class_1802.field_8833;
            case field_6172 -> item == class_1802.field_22029 || item == class_1802.field_8348 ||
                         item == class_1802.field_8396 || item == class_1802.field_8218 ||
                         item == class_1802.field_8416 || item == class_1802.field_8570;
            case field_6166 -> item == class_1802.field_22030 || item == class_1802.field_8285 ||
                         item == class_1802.field_8660 || item == class_1802.field_8313 ||
                         item == class_1802.field_8753 || item == class_1802.field_8370;
            default -> false;
        };
    }

    private static double getArmorValue(class_1799 stack, class_1304 slot) {
        if (stack.method_7960()) return 0;
        class_1792 item = stack.method_7909();
        
        if (item == class_1802.field_22027 || item == class_1802.field_22028 ||
            item == class_1802.field_22029 || item == class_1802.field_22030) return 100;
        if (item == class_1802.field_8805 || item == class_1802.field_8058 ||
            item == class_1802.field_8348 || item == class_1802.field_8285) return 80;
        if (item == class_1802.field_8743 || item == class_1802.field_8523 ||
            item == class_1802.field_8396 || item == class_1802.field_8660) return 60;
        if (item == class_1802.field_8283 || item == class_1802.field_8873 ||
            item == class_1802.field_8218 || item == class_1802.field_8313) return 50;
        if (item == class_1802.field_8862 || item == class_1802.field_8678 ||
            item == class_1802.field_8416 || item == class_1802.field_8753) return 40;
        if (item == class_1802.field_8267 || item == class_1802.field_8577 ||
            item == class_1802.field_8570 || item == class_1802.field_8370) return 20;
        if (item == class_1802.field_8090) return 55;
        if (item == class_1802.field_8833) return 10;
        
        return 0;
    }


    private static void equipBestWeapon(class_3222 bot) {
        BotSettings settings = BotSettings.get();
        var inventory = bot.method_31548();
        
        // РЁР°Рі 1: РќР°Р№С‚Рё Р»СѓС‡С€РµРµ РѕСЂСѓР¶РёРµ СЃ СѓС‡С‘С‚РѕРј preferSword
        int bestSlotIndex = -1;
        double bestScore = 0;
        
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            double score = getWeaponScore(stack, settings.isPreferSword());
            if (score > bestScore) {
                bestScore = score;
                bestSlotIndex = i;
            }
        }
        
        // РЁР°Рі 2: Р­РєРёРїРёСЂСѓРµРј Р»СѓС‡С€РµРµ РѕСЂСѓР¶РёРµ
        if (bestSlotIndex >= 0) {
            if (bestSlotIndex >= 9) {
                // РџРµСЂРµРјРµС‰Р°РµРј РІ С…РѕС‚Р±Р°СЂ СЃР»РѕС‚ 0
                class_1799 weapon = inventory.method_5438(bestSlotIndex);
                class_1799 slot0 = inventory.method_5438(0);
                inventory.method_5447(bestSlotIndex, slot0);
                inventory.method_5447(0, weapon);
                bestSlotIndex = 0;
            }
            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, bestSlotIndex);
        }
        
        // РЁР°Рі 3: Р’С‹Р±СЂР°СЃС‹РІР°РµРј С…СѓРґС€РµРµ РѕСЂСѓР¶РёРµ
        if (settings.isDropWorseWeapons() && bestScore > 0) {
            for (int i = 0; i < 36; i++) {
                if (i == bestSlotIndex) continue;
                
                class_1799 stack = inventory.method_5438(i);
                if (stack.method_7960()) continue;
                
                double score = getWeaponScore(stack, settings.isPreferSword());
                if (score > 0 && score < bestScore) {
                    dropItemBackward(bot, stack);
                    inventory.method_5447(i, class_1799.field_8037);
                }
            }
        }
    }

    /**
     * РџРѕР»СѓС‡РёС‚СЊ "РѕС‡РєРё" РѕСЂСѓР¶РёСЏ СЃ СѓС‡С‘С‚РѕРј preferSword
     * Р•СЃР»Рё preferSword = true, РјРµС‡Рё РїРѕР»СѓС‡Р°СЋС‚ Р±РѕРЅСѓСЃ +5 Рє РѕС‡РєР°Рј
     */
    private static double getWeaponScore(class_1799 stack, boolean preferSword) {
        if (stack.method_7960()) return 0;
        class_1792 item = stack.method_7909();
        
        double baseDamage = getWeaponDamage(stack);
        if (baseDamage == 0) return 0;
        
        // Р•СЃР»Рё РїСЂРµРґРїРѕС‡РёС‚Р°РµРј РјРµС‡ - РґР°С‘Рј РјРµС‡Р°Рј Р±РѕРЅСѓСЃ
        if (preferSword && isSword(item)) {
            return baseDamage + 5; // РњРµС‡ РІСЃРµРіРґР° Р±СѓРґРµС‚ РІС‹Р±СЂР°РЅ РµСЃР»Рё РµСЃС‚СЊ
        }
        
        return baseDamage;
    }
    
    /**
     * РџСЂРѕРІРµСЂСЏРµС‚, СЏРІР»СЏРµС‚СЃСЏ Р»Рё РїСЂРµРґРјРµС‚ РјРµС‡РѕРј
     */
    private static boolean isSword(class_1792 item) {
        return item == class_1802.field_22022 || 
               item == class_1802.field_8802 || 
               item == class_1802.field_8371 || 
               item == class_1802.field_8845 || 
               item == class_1802.field_8528 || 
               item == class_1802.field_8091;
    }

    private static double getWeaponDamage(class_1799 stack) {
        if (stack.method_7960()) return 0;
        class_1792 item = stack.method_7909();
        
        if (item == class_1802.field_22022) return 8;
        if (item == class_1802.field_22025) return 10;
        if (item == class_1802.field_8802) return 7;
        if (item == class_1802.field_8556) return 9;
        if (item == class_1802.field_8371) return 6;
        if (item == class_1802.field_8475) return 9;
        if (item == class_1802.field_8528) return 5;
        if (item == class_1802.field_8062) return 9;
        if (item == class_1802.field_8845) return 4;
        if (item == class_1802.field_8825) return 7;
        if (item == class_1802.field_8091) return 4;
        if (item == class_1802.field_8406) return 7;
        if (item == class_1802.field_8547) return 9;
        if (item == class_1802.field_49814) return 6;
        
        return 0;
    }
}
