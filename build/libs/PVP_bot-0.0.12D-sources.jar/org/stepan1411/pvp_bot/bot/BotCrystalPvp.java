package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * РћС‚РґРµР»СЊРЅС‹Р№ РєР»Р°СЃСЃ РґР»СЏ Crystal PVP
 * РџРѕР»РЅРѕСЃС‚СЊСЋ РєРѕРЅС‚СЂРѕР»РёСЂСѓРµС‚ РґРІРёР¶РµРЅРёРµ Рё Р±РѕР№ Р±РѕС‚Р°
 */
public class BotCrystalPvp {
    
    // РЎРѕСЃС‚РѕСЏРЅРёРµ Crystal PVP РґР»СЏ РєР°Р¶РґРѕРіРѕ Р±РѕС‚Р°
    private static class CrystalState {
        int step = 0;                    // РўРµРєСѓС‰РёР№ С€Р°Рі (0=РѕР±СЃРёРґРёР°РЅ, 1=РєСЂРёСЃС‚Р°Р»Р», 2=СѓРґР°СЂ)
        class_2338 lastObsidianPos = null; // РџРѕР·РёС†РёСЏ РїРѕСЃР»РµРґРЅРµРіРѕ РѕР±СЃРёРґРёР°РЅР°
        long lastActionTime = 0;         // Р’СЂРµРјСЏ РїРѕСЃР»РµРґРЅРµРіРѕ РґРµР№СЃС‚РІРёСЏ
        int cooldownTicks = 0;           // РљСѓР»РґР°СѓРЅ РјРµР¶РґСѓ РґРµР№СЃС‚РІРёСЏРјРё
        int stuckCounter = 0;            // РЎС‡С‘С‚С‡РёРє Р·Р°СЃС‚СЂРµРІР°РЅРёСЏ РЅР° РѕРґРЅРѕРј С€Р°РіРµ
        int lastStep = -1;               // РџРѕСЃР»РµРґРЅРёР№ РІС‹РїРѕР»РЅРµРЅРЅС‹Р№ С€Р°Рі
        int crystalNotFoundCounter = 0;  // РЎС‡С‘С‚С‡РёРє "РєСЂРёСЃС‚Р°Р»Р» РЅРµ РЅР°Р№РґРµРЅ"
        int crystalPlaceFailCounter = 0; // РЎС‡С‘С‚С‡РёРє РЅРµСѓРґР°С‡РЅС‹С… РїРѕРїС‹С‚РѕРє РїРѕСЃС‚Р°РІРёС‚СЊ РєСЂРёСЃС‚Р°Р»Р»
        java.util.Set<class_2338> triedPositions = new java.util.HashSet<>(); // РџРѕРїСЂРѕР±РѕРІР°РЅРЅС‹Рµ РїРѕР·РёС†РёРё РґР»СЏ РѕР±СЃРёРґРёР°РЅР°
        int obsidianPlaceAttempts = 0;   // РЎС‡С‘С‚С‡РёРє РїРѕРїС‹С‚РѕРє РїРѕСЃС‚Р°РІРёС‚СЊ РѕР±СЃРёРґРёР°РЅ РЅР° С‚РµРєСѓС‰РµР№ РїРѕР·РёС†РёРё
    }
    
    private static final java.util.Map<String, CrystalState> states = new java.util.HashMap<>();
    
    /**
     * РџРѕР»СѓС‡РёС‚СЊ СЃРѕСЃС‚РѕСЏРЅРёРµ Р±РѕС‚Р°
     */
    private static CrystalState getState(String botName) {
        return states.computeIfAbsent(botName, k -> new CrystalState());
    }
    
    /**
     * РџСЂРѕРІРµСЂРёС‚СЊ РјРѕР¶РµС‚ Р»Рё Р±РѕС‚ РёСЃРїРѕР»СЊР·РѕРІР°С‚СЊ Crystal PVP
     */
    public static boolean canUseCrystalPvp(class_3222 bot, class_1297 target, BotSettings settings) {
        if (!settings.isCrystalPvpEnabled()) return false;
        
        double distance = bot.method_5739(target);
        if (distance < 2.5 || distance > 8.0) return false;
        
        class_1661 inventory = bot.method_31548();
        return hasObsidian(inventory) && hasEndCrystal(inventory);
    }
    
    /**
     * Р“Р»Р°РІРЅС‹Р№ РјРµС‚РѕРґ - РІС‹РїРѕР»РЅСЏРµС‚ Crystal PVP
     * Р’РѕР·РІСЂР°С‰Р°РµС‚ true РµСЃР»Рё Р±РѕС‚ Р·Р°РЅСЏС‚ Crystal PVP (РЅРµ РЅСѓР¶РµРЅ РѕР±С‹С‡РЅС‹Р№ combat)
     */
    public static boolean doCrystalPvp(class_3222 bot, class_1297 target, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        CrystalState state = getState(bot.method_5477().getString());
        class_1937 world = bot.method_51469();
        double distance = bot.method_5739(target);
        
        // РџСЂРѕРІРµСЂРєР° РЅР° stuck: РµСЃР»Рё Р±РѕС‚ РґРѕР»РіРѕ РЅР° РѕРґРЅРѕРј С€Р°РіРµ - СЃР±СЂР°СЃС‹РІР°РµРј
        if (state.step == state.lastStep) {
            state.stuckCounter++;
            if (state.stuckCounter > 100) { // 5 СЃРµРєСѓРЅРґ (100 С‚РёРєРѕРІ)
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " STUCK on step " + state.step + "! Resetting state.");
                state.step = 0;
                state.lastObsidianPos = null;
                state.cooldownTicks = 0;
                state.stuckCounter = 0;
                return true;
            }
        } else {
            state.stuckCounter = 0;
            state.lastStep = state.step;
        }
        
        
        // РљСѓР»РґР°СѓРЅ РјРµР¶РґСѓ РґРµР№СЃС‚РІРёСЏРјРё
        if (state.cooldownTicks > 0) {
            state.cooldownTicks--;
            // Р’Рѕ РІСЂРµРјСЏ РєСѓР»РґР°СѓРЅР° - РґРµСЂР¶РёРј РґРёСЃС‚Р°РЅС†РёСЋ
            maintainDistance(bot, target, settings);
            return true;
        }
        
        // Р•СЃР»Рё РІСЂР°Рі СЃР»РёС€РєРѕРј РґР°Р»РµРєРѕ - РїРѕРґС…РѕРґРёРј
        if (distance > 8.0) {
            moveToward(bot, target, settings.getMoveSpeed());
            state.step = 0;
            state.lastObsidianPos = null;
            return true;
        }
        
        // Р•СЃР»Рё РІСЂР°Рі СЃР»РёС€РєРѕРј Р±Р»РёР·РєРѕ - РѕС‚С…РѕРґРёРј
        if (distance < 2.5) {
            moveAway(bot, target, settings.getMoveSpeed());
            return true;
        }
        
        // Р’РђР–РќРћ: Р•СЃР»Рё РµСЃС‚СЊ РєСЂРёСЃС‚Р°Р»Р» СЂСЏРґРѕРј - СЃСЂР°Р·Сѓ РїРµСЂРµС…РѕРґРёРј Рє Р°С‚Р°РєРµ
        // РќРћ С‚РѕР»СЊРєРѕ РµСЃР»Рё РЅРµС‚ РєСѓР»РґР°СѓРЅР° (С‡С‚РѕР±С‹ РЅРµ РїСЂРµСЂС‹РІР°С‚СЊ СѓСЃС‚Р°РЅРѕРІРєСѓ)
        class_1297 nearCrystal = findNearestEndCrystal(bot, target, 6.0);
        if (nearCrystal != null && state.step != 2 && state.cooldownTicks == 0) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " РѕР±РЅР°СЂСѓР¶РёР» РєСЂРёСЃС‚Р°Р»Р», РїРµСЂРµС…РѕРґ Рє С€Р°РіСѓ 2 (С‚РµРєСѓС‰РёР№ step: " + state.step + ")");
            state.step = 2;
            state.cooldownTicks = 0; // РЎСЂР°Р·Сѓ Р°С‚Р°РєСѓРµРј
        }
        
        // Р’С‹РїРѕР»РЅСЏРµРј С‚РµРєСѓС‰РёР№ С€Р°Рі
        switch (state.step) {
            case 0: // РЁР°Рі 1: РЎС‚Р°РІРёРј РѕР±СЃРёРґРёР°РЅ
                return stepPlaceObsidian(bot, target, state, server, world, settings);
                
            case 1: // РЁР°Рі 2: РЎС‚Р°РІРёРј РєСЂРёСЃС‚Р°Р»Р»
                return stepPlaceCrystal(bot, target, state, server, world, settings);
                
            case 2: // РЁР°Рі 3: Р‘СЊС‘Рј РєСЂРёСЃС‚Р°Р»Р»
                return stepAttackCrystal(bot, target, state, server, world, settings, distance);
                
            default:
                state.step = 0;
                return true;
        }
    }
    
    /**
     * РЁР°Рі 0: РЈСЃС‚Р°РЅРѕРІРєР° РѕР±СЃРёРґРёР°РЅР°
     */
    private static boolean stepPlaceObsidian(class_3222 bot, class_1297 target, CrystalState state, 
                                            net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        
        // РЎРќРђР§РђР›Рђ РїСЂРѕРІРµСЂСЏРµРј РµСЃС‚СЊ Р»Рё СѓР¶Рµ РѕР±СЃРёРґРёР°РЅ СЂСЏРґРѕРј СЃ РІСЂР°РіРѕРј (РІ СЂР°РґРёСѓСЃРµ 5 blocks)
        class_2338 existingObsidian = findExistingObsidian(bot, target, world, 5.0);
        if (existingObsidian != null) {
            double distToExisting = Math.sqrt(bot.method_5649(existingObsidian.method_10263() + 0.5, existingObsidian.method_10264() + 0.5, existingObsidian.method_10260() + 0.5));
            
            if (distToExisting <= 4.0) {
                // РћР±СЃРёРґРёР°РЅ РµСЃС‚СЊ Рё Р±РѕС‚ РјРѕР¶РµС‚ РґРѕ РЅРµРіРѕ РґРѕСЃС‚Р°С‚СЊ - РёСЃРїРѕР»СЊР·СѓРµРј РµРіРѕ!
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " using existing obsidian at " + existingObsidian);
                state.lastObsidianPos = existingObsidian;
                state.step = 1; // РЎСЂР°Р·Сѓ Рє СѓСЃС‚Р°РЅРѕРІРєРµ РєСЂРёСЃС‚Р°Р»Р»Р°
                state.cooldownTicks = 0; // Р‘РµР· РєСѓР»РґР°СѓРЅР°
                state.stuckCounter = 0; // РЎР±СЂР°СЃС‹РІР°РµРј СЃС‡С‘С‚С‡РёРє Р·Р°СЃС‚СЂРµРІР°РЅРёСЏ
                return true;
            } else {
                // РћР±СЃРёРґРёР°РЅ РµСЃС‚СЊ РЅРѕ РґР°Р»РµРєРѕ - РїРѕРґС…РѕРґРёРј Р±Р»РёР¶Рµ
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " approaching existing obsidian, distance: " + String.format("%.2f", distToExisting));
                moveToward(bot, target, settings.getMoveSpeed());
                return true;
            }
        }
        
        // РћР±СЃРёРґРёР°РЅР° СЂСЏРґРѕРј РЅРµС‚ - СЃС‚Р°РІРёРј РЅРѕРІС‹Р№
        
        // РџСЂРѕРІРµСЂСЏРµРј РЅР°Р»РёС‡РёРµ РѕР±СЃРёРґРёР°РЅР°
        int obsidianSlot = findObsidian(inventory);
        if (obsidianSlot < 0) {
            return false; // РќРµС‚ РѕР±СЃРёРґРёР°РЅР° - РІС‹С…РѕРґРёРј РёР· Crystal PVP
        }
        
        // РќР°С…РѕРґРёРј РїРѕР·РёС†РёСЋ РґР»СЏ РѕР±СЃРёРґРёР°РЅР°
        class_2338 obsidianPos = findBestObsidianPosition(bot, target, world, state.triedPositions);
        if (obsidianPos == null) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " could not find obsidian position!");
            // РќРµС‚ РјРµСЃС‚Р° - СЃР±СЂР°СЃС‹РІР°РµРј РїРѕРїСЂРѕР±РѕРІР°РЅРЅС‹Рµ РїРѕР·РёС†РёРё Рё РїСЂРѕР±СѓРµРј СЃРЅРѕРІР°
            if (!state.triedPositions.isEmpty()) {
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " clearing tried positions (" + state.triedPositions.size() + " positions)");
                state.triedPositions.clear();
            }
            // Р”РµСЂР¶РёРј РґРёСЃС‚Р°РЅС†РёСЋ
            maintainDistance(bot, target, settings);
            return true;
        }
        
        // РџСЂРѕРІРµСЂСЏРµРј РґРёСЃС‚Р°РЅС†РёСЋ РґРѕ РїРѕР·РёС†РёРё
        double distToPos = Math.sqrt(bot.method_5649(obsidianPos.method_10263() + 0.5, obsidianPos.method_10264() + 0.5, obsidianPos.method_10260() + 0.5));
        
        if (distToPos > 3.0) {
            moveToward(bot, target, settings.getMoveSpeed());
            return true;
        }
        
        // РћСЃС‚Р°РЅР°РІР»РёРІР°РµРј Р±РѕС‚Р°
        bot.method_18800(0, bot.method_18798().field_1351, 0);
        
        // РџРµСЂРµРєР»СЋС‡Р°РµРјСЃСЏ РЅР° РѕР±СЃРёРґРёР°РЅ
        if (!selectItem(bot, obsidianSlot)) {
            return true; // РќРµ СѓРґР°Р»РѕСЃСЊ РїРµСЂРµРєР»СЋС‡РёС‚СЊ - РїРѕРїСЂРѕР±СѓРµРј РІ СЃР»РµРґСѓСЋС‰РµРј С‚РёРєРµ
        }
        
        // РЎРјРѕС‚СЂРёРј РЅР° РїРѕР·РёС†РёСЋ
        lookAt(bot, obsidianPos);
        
        // РЈРІРµР»РёС‡РёРІР°РµРј СЃС‡С‘С‚С‡РёРє РїРѕРїС‹С‚РѕРє РґР»СЏ СЌС‚РѕР№ РїРѕР·РёС†РёРё
        state.obsidianPlaceAttempts++;
        
        // Р•СЃР»Рё 3 РїРѕРїС‹С‚РєРё РЅР° РѕРґРЅРѕР№ РїРѕР·РёС†РёРё РЅРµ СѓРґР°Р»РёСЃСЊ - РїСЂРѕР±СѓРµРј РґСЂСѓРіСѓСЋ
        if (state.obsidianPlaceAttempts >= 3) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " failed to place obsidian 3 times at " + obsidianPos + ", trying different position");
            state.triedPositions.add(obsidianPos);
            state.obsidianPlaceAttempts = 0;
            state.cooldownTicks = 3;
            return true;
        }
        
        // РЎС‚Р°РІРёРј Р±Р»РѕРє С‡РµСЂРµР· Carpet РєРѕРјР°РЅРґСѓ
        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " use once", 
                server.method_3739()
            );
            
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " placed obsidian at " + obsidianPos + " (attempt " + state.obsidianPlaceAttempts + "/3)");
            
            // РЈСЃРїРµС€РЅРѕ РїРѕСЃС‚Р°РІРёР»Рё - РїРµСЂРµС…РѕРґРёРј Рє СЃР»РµРґСѓСЋС‰РµРјСѓ С€Р°РіСѓ
            state.lastObsidianPos = obsidianPos;
            state.step = 1;
            state.cooldownTicks = 5; // РљСѓР»РґР°СѓРЅ С‡С‚РѕР±С‹ Р±Р»РѕРє СѓСЃРїРµР» СѓСЃС‚Р°РЅРѕРІРёС‚СЊСЃСЏ
            state.stuckCounter = 0; // РЎР±СЂР°СЃС‹РІР°РµРј СЃС‡С‘С‚С‡РёРє Р·Р°СЃС‚СЂРµРІР°РЅРёСЏ
            state.obsidianPlaceAttempts = 0; // РЎР±СЂР°СЃС‹РІР°РµРј СЃС‡С‘С‚С‡РёРє РїРѕРїС‹С‚РѕРє
            
        } catch (Exception e) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " error placing obsidian: " + e.getMessage());
            // РћС€РёР±РєР° - РїРѕРїСЂРѕР±СѓРµРј СЃРЅРѕРІР°
        }
        
        // РќР• РїРѕРІРѕСЂР°С‡РёРІР°РµРј РіРѕР»РѕРІСѓ РѕР±СЂР°С‚РЅРѕ - РѕСЃС‚Р°РІР»СЏРµРј СЃРјРѕС‚СЂРµС‚СЊ РЅР° РѕР±СЃРёРґРёР°РЅ
        return true;
    }
    
    /**
     * РЁР°Рі 1: РЈСЃС‚Р°РЅРѕРІРєР° РєСЂРёСЃС‚Р°Р»Р»Р°
     */
    private static boolean stepPlaceCrystal(class_3222 bot, class_1297 target, CrystalState state,
                                           net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        
        // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ РѕР±СЃРёРґРёР°РЅ СѓСЃС‚Р°РЅРѕРІР»РµРЅ
        if (state.lastObsidianPos == null) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " no obsidian position!");
            state.step = 0;
            return true;
        }
        
        // Р’РђР–РќРћ: РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ РЅР° РїРѕР·РёС†РёРё РґРµР№СЃС‚РІРёС‚РµР»СЊРЅРѕ РѕР±СЃРёРґРёР°РЅ
        net.minecraft.class_2680 blockAtPos = world.method_8320(state.lastObsidianPos);
        
        if (!blockAtPos.method_26204().toString().contains("obsidian")) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " NO obsidian at position! Returning to step 0");
            // Р”РѕР±Р°РІР»СЏРµРј СЌС‚Сѓ РїРѕР·РёС†РёСЋ РІ СЃРїРёСЃРѕРє РЅРµСѓРґР°С‡РЅС‹С…
            if (state.lastObsidianPos != null) {
                state.triedPositions.add(state.lastObsidianPos);
            }
            state.step = 0;
            state.lastObsidianPos = null;
            state.obsidianPlaceAttempts = 0;
            return true;
        }
        
        // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ РЅР°Рґ РѕР±СЃРёРґРёР°РЅРѕРј СЃРІРѕР±РѕРґРЅРѕ
        net.minecraft.class_2680 blockAbove = world.method_8320(state.lastObsidianPos.method_10084());
        
        if (!blockAbove.method_26215() && !blockAbove.method_45474()) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " NO space above obsidian! Returning to step 0");
            state.step = 0;
            state.lastObsidianPos = null;
            return true;
        }
        
        // РџСЂРѕРІРµСЂСЏРµРј РЅР°Р»РёС‡РёРµ РєСЂРёСЃС‚Р°Р»Р»Р°
        int crystalSlot = findEndCrystal(inventory);
        if (crystalSlot < 0) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " no crystals in inventory! Exiting Crystal PVP.");
            state.step = 0;
            state.lastObsidianPos = null;
            state.stuckCounter = 0;
            return false; // РќРµС‚ РєСЂРёСЃС‚Р°Р»Р»Р° - РІС‹С…РѕРґРёРј РёР· Crystal PVP
        }
        
        // РћСЃС‚Р°РЅР°РІР»РёРІР°РµРј Р±РѕС‚Р°
        bot.method_18800(0, bot.method_18798().field_1351, 0);
        
        // РџРµСЂРµРєР»СЋС‡Р°РµРјСЃСЏ РЅР° РєСЂРёСЃС‚Р°Р»Р»
        if (!selectItem(bot, crystalSlot)) {
            return true; // РќРµ СѓРґР°Р»РѕСЃСЊ РїРµСЂРµРєР»СЋС‡РёС‚СЊ - РїРѕРїСЂРѕР±СѓРµРј РІ СЃР»РµРґСѓСЋС‰РµРј С‚РёРєРµ
        }
        
        // РЎРјРѕС‚СЂРёРј РЅР° РЎРђРњ РћР‘РЎРР”РРђРќ (РЅРµ РЅР° РІРѕР·РґСѓС… РЅР°Рґ РЅРёРј!)
        // РљСЂРёСЃС‚Р°Р»Р» РјРѕР¶РЅРѕ РїРѕСЃС‚Р°РІРёС‚СЊ С‚С‹РєРЅСѓРІ РїРѕ Р›Р®Р‘РћР™ РіСЂР°РЅРё РѕР±СЃРёРґРёР°РЅР°
        lookAt(bot, state.lastObsidianPos);
        
        // Р’РђР–РќРћ: РџСЂРѕРІРµСЂСЏРµРј СЃС‡С‘С‚С‡РёРє РЅРµСѓРґР°С‡РЅС‹С… РїРѕРїС‹С‚РѕРє РџР•Р Р•Р” СѓСЃС‚Р°РЅРѕРІРєРѕР№
        if (state.crystalPlaceFailCounter >= 5) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " STUCK - crystal placement failed 5 times! Resetting state.");
            state.step = 0;
            state.lastObsidianPos = null;
            state.cooldownTicks = 5;
            state.crystalPlaceFailCounter = 0;
            return true;
        }
        
        // РЎС‚Р°РІРёРј РєСЂРёСЃС‚Р°Р»Р» С‡РµСЂРµР· Carpet РєРѕРјР°РЅРґСѓ
        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " use once", 
                server.method_3739()
            );
            
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " placed crystal (clicked obsidian at " + state.lastObsidianPos + ") - attempt " + (state.crystalPlaceFailCounter + 1) + "/5");
            
            // РЈРІРµР»РёС‡РёРІР°РµРј СЃС‡С‘С‚С‡РёРє РЅРµСѓРґР°С‡РЅС‹С… РїРѕРїС‹С‚РѕРє (СЃР±СЂРѕСЃРёС‚СЃСЏ РµСЃР»Рё РєСЂРёСЃС‚Р°Р»Р» РїРѕСЏРІРёС‚СЃСЏ)
            state.crystalPlaceFailCounter++;
            
            // РЈСЃРїРµС€РЅРѕ РІС‹РїРѕР»РЅРёР»Рё РєРѕРјР°РЅРґСѓ - РїРµСЂРµС…РѕРґРёРј Рє Р°С‚Р°РєРµ
            state.step = 2;
            state.cooldownTicks = 5; // РљСѓР»РґР°СѓРЅ С‡С‚РѕР±С‹ РєСЂРёСЃС‚Р°Р»Р» СѓСЃРїРµР» РїРѕСЏРІРёС‚СЊСЃСЏ
            state.stuckCounter = 0; // РЎР±СЂР°СЃС‹РІР°РµРј СЃС‡С‘С‚С‡РёРє Р·Р°СЃС‚СЂРµРІР°РЅРёСЏ
            
        } catch (Exception e) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " error placing crystal: " + e.getMessage());
            // РћС€РёР±РєР° - РІРѕР·РІСЂР°С‰Р°РµРјСЃСЏ Рє РѕР±СЃРёРґРёР°РЅСѓ
            state.step = 0;
            state.lastObsidianPos = null;
            state.crystalPlaceFailCounter = 0;
        }
        
        // РќР• РїРѕРІРѕСЂР°С‡РёРІР°РµРј РіРѕР»РѕРІСѓ РѕР±СЂР°С‚РЅРѕ - РѕСЃС‚Р°РІР»СЏРµРј СЃРјРѕС‚СЂРµС‚СЊ РЅР° РєСЂРёСЃС‚Р°Р»Р»
        return true;
    }
    
    /**
     * РЁР°Рі 2: РђС‚Р°РєР° РєСЂРёСЃС‚Р°Р»Р»Р°
     */
    private static boolean stepAttackCrystal(class_3222 bot, class_1297 target, CrystalState state,
                                            net.minecraft.server.MinecraftServer server, class_1937 world, 
                                            BotSettings settings, double distance) {
        class_1661 inventory = bot.method_31548();
        
        // РћСЃС‚Р°РЅР°РІР»РёРІР°РµРј Р±РѕС‚Р° РІРѕ РІСЂРµРјСЏ Р°С‚Р°РєРё
        bot.method_18800(0, bot.method_18798().field_1351, 0);
        
        // РџРµСЂРµРєР»СЋС‡Р°РµРјСЃСЏ РЅР° РѕСЂСѓР¶РёРµ
        int weaponSlot = findMeleeWeapon(inventory);
        if (weaponSlot >= 0) {
            selectItem(bot, weaponSlot);
        }
        
        // РС‰РµРј РєСЂРёСЃС‚Р°Р»Р»
        class_1297 crystal = findNearestEndCrystal(bot, target, 6.0);
        
        if (crystal != null) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " found crystal at distance " + bot.method_5739(crystal));
            
            // РЎРјРѕС‚СЂРёРј РЅР° РєСЂРёСЃС‚Р°Р»Р»
            lookAtEntity(bot, crystal);
            
            // РЎР±СЂР°СЃС‹РІР°РµРј СЃС‡С‘С‚С‡РёРє "РєСЂРёСЃС‚Р°Р»Р» РЅРµ РЅР°Р№РґРµРЅ"
            state.crystalNotFoundCounter = 0;
            // РЎР±СЂР°СЃС‹РІР°РµРј СЃС‡С‘С‚С‡РёРє РЅРµСѓРґР°С‡РЅС‹С… РїРѕРїС‹С‚РѕРє СѓСЃС‚Р°РЅРѕРІРєРё (РєСЂРёСЃС‚Р°Р»Р» РїРѕСЏРІРёР»СЃСЏ!)
            state.crystalPlaceFailCounter = 0;
            
            // Р‘СЊС‘Рј РєСЂРёСЃС‚Р°Р»Р» РќРђРџР РЇРњРЈР® (РЅРµ С‡РµСЂРµР· РєРѕРјР°РЅРґСѓ)
            bot.method_7324(crystal);
            bot.method_6104(class_1268.field_5808);
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " hit crystal!");
            
            // Р РµС€Р°РµРј С‡С‚Рѕ РґРµР»Р°С‚СЊ РґР°Р»СЊС€Рµ
            if (distance <= 4.5 && state.lastObsidianPos != null) {
                // Р’СЂР°Рі СЂСЏРґРѕРј - СЃРїР°РјРёРј РєСЂРёСЃС‚Р°Р»Р»С‹
                state.step = 1;
                state.cooldownTicks = 2;
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " moving to step 1 (new crystal)");
            } else {
                // Р’СЂР°Рі РґР°Р»РµРєРѕ - РЅР°С‡РёРЅР°РµРј Р·Р°РЅРѕРІРѕ
                state.step = 0;
                state.lastObsidianPos = null;
                state.cooldownTicks = 5;
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " moving to step 0 (new obsidian)");
            }
            
        } else {
            state.crystalNotFoundCounter++;
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " DID NOT FIND crystal! (" + state.crystalNotFoundCounter + "/3)");
            
            // Р•СЃР»Рё 3 СЂР°Р·Р° РЅРµ РЅР°С€Р»Рё РєСЂРёСЃС‚Р°Р»Р» - СЃР±СЂР°СЃС‹РІР°РµРј СЃРѕСЃС‚РѕСЏРЅРёРµ
            if (state.crystalNotFoundCounter >= 3) {
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " STUCK - crystal not found 3 times! Resetting state.");
                state.step = 0;
                state.lastObsidianPos = null;
                state.cooldownTicks = 5;
                state.crystalNotFoundCounter = 0;
                return true;
            }
            
            // РљСЂРёСЃС‚Р°Р»Р»Р° РЅРµС‚ - РїСЂРѕР±СѓРµРј РїРѕСЃС‚Р°РІРёС‚СЊ СЃРЅРѕРІР°
            if (state.lastObsidianPos != null) {
                state.step = 1;
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " returning to step 1 (place crystal)");
            } else {
                state.step = 0;
                System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " returning to step 0 (place obsidian)");
            }
            state.cooldownTicks = 3;
        }
        
        // РќР• РїРѕРІРѕСЂР°С‡РёРІР°РµРј РіРѕР»РѕРІСѓ РѕР±СЂР°С‚РЅРѕ Рє РёРіСЂРѕРєСѓ - РѕСЃС‚Р°РІР»СЏРµРј СЃРјРѕС‚СЂРµС‚СЊ РЅР° РєСЂРёСЃС‚Р°Р»Р»
        // Р“РѕР»РѕРІР° РїРѕРІРµСЂРЅС‘С‚СЃСЏ Рє РёРіСЂРѕРєСѓ С‚РѕР»СЊРєРѕ РІ СЃР»РµРґСѓСЋС‰РµРј С†РёРєР»Рµ
        
        return true;
    }
    
    /**
     * РџРѕРґРґРµСЂР¶РёРІР°С‚СЊ РѕРїС‚РёРјР°Р»СЊРЅСѓСЋ РґРёСЃС‚Р°РЅС†РёСЋ (3-5 blocks)
     */
    private static void maintainDistance(class_3222 bot, class_1297 target, BotSettings settings) {
        double distance = bot.method_5739(target);
        
        if (distance < 3.0) {
            // РЎР»РёС€РєРѕРј Р±Р»РёР·РєРѕ - РѕС‚С…РѕРґРёРј
            moveAway(bot, target, settings.getMoveSpeed() * 0.7);
        } else if (distance > 5.5) {
            // РЎР»РёС€РєРѕРј РґР°Р»РµРєРѕ - РїРѕРґС…РѕРґРёРј
            moveToward(bot, target, settings.getMoveSpeed() * 0.7);
        } else {
            // РћРїС‚РёРјР°Р»СЊРЅР°СЏ РґРёСЃС‚Р°РЅС†РёСЏ - РїСЂРѕСЃС‚Рѕ СЃРјРѕС‚СЂРёРј РЅР° С†РµР»СЊ, РЅРµ РґРІРёРіР°РµРјСЃСЏ
            lookAtEntity(bot, target);
        }
    }
    
    /**
     * Р”РІРёРіР°С‚СЊСЃСЏ Рє С†РµР»Рё
     */
    private static void moveToward(class_3222 bot, class_1297 target, double speed) {
        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
        class_243 direction = targetPos.method_1020(botPos).method_1029();
        
        bot.method_18800(direction.field_1352 * speed, bot.method_18798().field_1351, direction.field_1350 * speed);
        bot.field_64356 = true;
        
        lookAtEntity(bot, target);
    }
    
    /**
     * РћС‚С…РѕРґРёС‚СЊ from target
     */
    private static void moveAway(class_3222 bot, class_1297 target, double speed) {
        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
        class_243 direction = botPos.method_1020(targetPos).method_1029();
        
        bot.method_18800(direction.field_1352 * speed, bot.method_18798().field_1351, direction.field_1350 * speed);
        bot.field_64356 = true;
        
        lookAtEntity(bot, target);
    }
    
    /**
     * РЎС‚СЂРµР№С„ (РґРІРёР¶РµРЅРёРµ РїРѕ РєСЂСѓРіСѓ)
     */
    private static void strafe(class_3222 bot, class_1297 target, double speed) {
        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
        class_243 toTarget = targetPos.method_1020(botPos).method_1029();
        
        // РџРµСЂРїРµРЅРґРёРєСѓР»СЏСЂРЅРѕРµ РЅР°РїСЂР°РІР»РµРЅРёРµ (СЃС‚СЂРµР№С„ РІР»РµРІРѕ)
        class_243 strafeDir = new class_243(-toTarget.field_1350, 0, toTarget.field_1352);
        
        bot.method_18800(strafeDir.field_1352 * speed, bot.method_18798().field_1351, strafeDir.field_1350 * speed);
        bot.field_64356 = true;
        
        lookAtEntity(bot, target);
    }
    
    /**
     * РЎРјРѕС‚СЂРµС‚СЊ РЅР° РїРѕР·РёС†РёСЋ
     */
    private static void lookAt(class_3222 bot, class_2338 pos) {
        class_243 target = new class_243(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
        class_243 botPos = bot.method_33571();
        
        double dx = target.field_1352 - botPos.field_1352;
        double dy = target.field_1351 - botPos.field_1351;
        double dz = target.field_1350 - botPos.field_1350;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) (Math.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(Math.atan2(dy, horizontalDist) * (180.0 / Math.PI));
        
        bot.method_36456(yaw);
        bot.method_36457(pitch);
        bot.method_5847(yaw);
    }
    
    /**
     * РЎРјРѕС‚СЂРµС‚СЊ РЅР° СЃСѓС‰РЅРѕСЃС‚СЊ
     */
    private static void lookAtEntity(class_3222 bot, class_1297 target) {
        class_243 targetPos = target.method_33571();
        class_243 botPos = bot.method_33571();
        
        double dx = targetPos.field_1352 - botPos.field_1352;
        double dy = targetPos.field_1351 - botPos.field_1351;
        double dz = targetPos.field_1350 - botPos.field_1350;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) (Math.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(Math.atan2(dy, horizontalDist) * (180.0 / Math.PI));
        
        bot.method_36456(yaw);
        bot.method_36457(pitch);
        bot.method_5847(yaw);
    }
    
    /**
     * Р’С‹Р±СЂР°С‚СЊ РїСЂРµРґРјРµС‚ РІ СЂСѓРєРµ
     */
    private static boolean selectItem(class_3222 bot, int slot) {
        class_1661 inventory = bot.method_31548();
        
        // Р•СЃР»Рё РїСЂРµРґРјРµС‚ РІ РёРЅРІРµРЅС‚Р°СЂРµ (РЅРµ РІ С…РѕС‚Р±Р°СЂРµ) - РїРµСЂРµРјРµС‰Р°РµРј
        if (slot >= 9) {
            class_1799 item = inventory.method_5438(slot);
            class_1799 current = inventory.method_5438(0);
            inventory.method_5447(slot, current);
            inventory.method_5447(0, item);
            slot = 0;
        }
        
        // РџРµСЂРµРєР»СЋС‡Р°РµРј СЃР»РѕС‚
        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, slot);
        return true;
    }
    
    /**
     * РќР°Р№С‚Рё РѕР±СЃРёРґРёР°РЅ СЂСЏРґРѕРј СЃ РІСЂР°РіРѕРј (Р»СЋР±РѕР№, РЅРµ С‚РѕР»СЊРєРѕ С‚РѕС‚ С‡С‚Рѕ РїРѕСЃС‚Р°РІРёР» Р±РѕС‚)
     */
    private static class_2338 findExistingObsidian(class_3222 bot, class_1297 target, class_1937 world, double maxDistance) {
        class_2338 targetPos = target.method_24515();
        
        // РџСЂРѕРІРµСЂСЏРµРј Р±Р»РѕРєРё РІРѕРєСЂСѓРі РІСЂР°РіР° РІ СЂР°РґРёСѓСЃРµ maxDistance
        int radius = (int) Math.ceil(maxDistance);
        
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2338 pos = targetPos.method_10069(dx, dy, dz);
                    
                    // РџСЂРѕРІРµСЂСЏРµРј РґРёСЃС‚Р°РЅС†РёСЋ РѕС‚ РІСЂР°РіР°
                    double distFromTarget = Math.sqrt(target.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5));
                    if (distFromTarget > maxDistance) continue;
                    
                    // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ СЌС‚Рѕ РѕР±СЃРёРґРёР°РЅ
                    net.minecraft.class_2680 blockState = world.method_8320(pos);
                    if (!blockState.method_26204().toString().contains("obsidian")) continue;
                    
                    // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ РЅР°Рґ РѕР±СЃРёРґРёР°РЅРѕРј СЃРІРѕР±РѕРґРЅРѕ
                    net.minecraft.class_2680 blockAbove = world.method_8320(pos.method_10084());
                    if (!blockAbove.method_26215() && !blockAbove.method_45474()) continue;
                    
                    // Р’РђР–РќРћ: РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ Р‘РћРў РјРѕР¶РµС‚ РґРѕСЃС‚Р°С‚СЊ РґРѕ РѕР±СЃРёРґРёР°РЅР° (в‰¤ 4 Р±Р»РѕРєР°)
                    double distFromBot = Math.sqrt(bot.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5));
                    if (distFromBot > 4.0) {
                        continue;
                    }
                    
                    System.out.println("[Crystal PVP] Found suitable obsidian at " + pos + ", distance from enemy: " + String.format("%.2f", distFromTarget) + ", from bot: " + String.format("%.2f", distFromBot));
                    return pos;
                }
            }
        }
        
        return null;
    }
    
    /**
     * РќР°Р№С‚Рё Р»СѓС‡С€СѓСЋ РїРѕР·РёС†РёСЋ РґР»СЏ РѕР±СЃРёРґРёР°РЅР° - Р РЇР”РћРњ СЃ РІСЂР°РіРѕРј
     */
    private static class_2338 findBestObsidianPosition(class_3222 bot, class_1297 target, class_1937 world, java.util.Set<class_2338> triedPositions) {
        class_2338 targetPos = target.method_24515();
        
        // РџСЂРѕРІРµСЂСЏРµРј Р±Р»РѕРєРё РІРѕРєСЂСѓРі РІСЂР°РіР°
        class_2338[] candidates = {
            targetPos.method_10095(),
            targetPos.method_10072(),
            targetPos.method_10078(),
            targetPos.method_10067(),
            targetPos.method_10095().method_10078(),
            targetPos.method_10095().method_10067(),
            targetPos.method_10072().method_10078(),
            targetPos.method_10072().method_10067(),
        };
        
        for (class_2338 pos : candidates) {
            // РџСЂРѕРїСѓСЃРєР°РµРј СѓР¶Рµ РїРѕРїСЂРѕР±РѕРІР°РЅРЅС‹Рµ РїРѕР·РёС†РёРё
            if (triedPositions.contains(pos)) {
                continue;
            }
            
            // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ Р±Р»РѕРє СЃРІРѕР±РѕРґРµРЅ
            if (!world.method_8320(pos).method_26215() && !world.method_8320(pos).method_45474()) {
                continue;
            }
            
            // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ РЅР°Рґ Р±Р»РѕРєРѕРј РµСЃС‚СЊ РјРµСЃС‚Рѕ РґР»СЏ РєСЂРёСЃС‚Р°Р»Р»Р°
            if (!world.method_8320(pos.method_10084()).method_26215() && !world.method_8320(pos.method_10084()).method_45474()) {
                continue;
            }
            
            // РџСЂРѕРІРµСЂСЏРµРј РґРёСЃС‚Р°РЅС†РёСЋ РґРѕ Р±РѕС‚Р°
            double dist = Math.sqrt(bot.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5));
            
            if (dist <= 4.0) {
                System.out.println("[Crystal PVP] Found suitable position: " + pos);
                return pos;
            }
        }
        
        System.out.println("[Crystal PVP] No suitable positions found!");
        return null;
    }
    
    /**
     * РќР°Р№С‚Рё Р±Р»РёР¶Р°Р№С€РёР№ End Crystal
     */
    private static class_1297 findNearestEndCrystal(class_3222 bot, class_1297 target, double maxDistance) {
        class_1937 world = bot.method_51469();
        net.minecraft.class_238 searchBox = target.method_5829().method_1014(maxDistance);
        
        class_1297 nearestCrystal = null;
        double nearestDist = maxDistance + 1;
        int crystalCount = 0;
        
        
        for (class_1297 entity : world.method_8335(bot, searchBox)) {
            
            if (entity instanceof net.minecraft.class_1511) {
                crystalCount++;
                double dist = target.method_5739(entity);
                System.out.println("[Crystal PVP] Р­С‚Рѕ РєСЂРёСЃС‚Р°Р»Р»! Р”РёСЃС‚Р°РЅС†РёСЏ from target: " + String.format("%.2f", dist));
                if (dist < nearestDist) {
                    nearestDist = dist;
                    nearestCrystal = entity;
                }
            }
        }
        
        if (crystalCount > 0) {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " found " + crystalCount + " crystals in radius " + maxDistance);
        } else {
            System.out.println("[Crystal PVP] " + bot.method_5477().getString() + " РќР• found РЅРё РѕРґРЅРѕРіРѕ РєСЂРёСЃС‚Р°Р»Р»Р°!");
        }
        
        return nearestCrystal;
    }
    
    /**
     * РќР°Р№С‚Рё РѕР±СЃРёРґРёР°РЅ РІ РёРЅРІРµРЅС‚Р°СЂРµ
     */
    private static int findObsidian(class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8281) return i;
        }
        return -1;
    }
    
    /**
     * РќР°Р№С‚Рё End Crystal РІ РёРЅРІРµРЅС‚Р°СЂРµ
     */
    private static int findEndCrystal(class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8301) return i;
        }
        return -1;
    }
    
    /**
     * РќР°Р№С‚Рё РѕСЂСѓР¶РёРµ Р±Р»РёР¶РЅРµРіРѕ Р±РѕСЏ
     */
    private static int findMeleeWeapon(class_1661 inventory) {
        // РџСЂРёРѕСЂРёС‚РµС‚: РјРµС‡ > С‚РѕРїРѕСЂ
        int bestSlot = -1;
        int bestPriority = -1;
        
        // РС‰РµРј РІРѕ РІСЃС‘Рј РёРЅРІРµРЅС‚Р°СЂРµ (0-35)
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            int priority = -1;
            
            if (stack.method_7909().toString().contains("sword")) {
                priority = 10;
            } else if (stack.method_7909().toString().contains("axe")) {
                priority = 5;
            }
            
            if (priority > bestPriority) {
                bestPriority = priority;
                bestSlot = i;
            }
        }
        
        return bestSlot;
    }
    
    /**
     * РџСЂРѕРІРµСЂРёС‚СЊ РЅР°Р»РёС‡РёРµ РѕР±СЃРёРґРёР°РЅР°
     */
    private static boolean hasObsidian(class_1661 inventory) {
        return findObsidian(inventory) >= 0;
    }
    
    /**
     * РџСЂРѕРІРµСЂРёС‚СЊ РЅР°Р»РёС‡РёРµ End Crystal
     */
    private static boolean hasEndCrystal(class_1661 inventory) {
        return findEndCrystal(inventory) >= 0;
    }
    
    /**
     * РЎР±СЂРѕСЃРёС‚СЊ СЃРѕСЃС‚РѕСЏРЅРёРµ Р±РѕС‚Р°
     */
    public static void reset(String botName) {
        states.remove(botName);
    }
}
