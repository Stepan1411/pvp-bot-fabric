package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1744;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import java.util.*;

public class BotCombat {
    

    private static final Map<String, CombatState> combatStates = new HashMap<>();
    
    public static class CombatState {
        public class_1297 target = null;
        public String forcedTargetName = null;
        public int attackCooldown = 0;
        public int bowDrawTicks = 0;
        public boolean isDrawingBow = false;
        public class_1297 lastAttacker = null;
        public long lastAttackTime = 0;
        public WeaponMode currentMode = WeaponMode.MELEE;
        public float lastHealth = 20.0f;
        public boolean isRetreating = false;
        

        public boolean isChargingSpear = false;
        public int spearChargeTicks = 0;
        

        public int cobwebCooldown = 0;
        

        public boolean isUsingShield = false;
        public int shieldToggleCooldown = 0;
        public int airTimeTicks = 0;
        public boolean shieldBroken = false;
        public long shieldBrokenTime = 0;
        public boolean isPlacingCobweb = false;
        public int cobwebPlaceTicks = 0;
        

        public boolean isCrystalPvping = false;
        public int crystalCooldown = 0;
        public net.minecraft.class_2338 lastObsidianPos = null;
        public int crystalPvpStep = 0;
        public int crystalPvpTicks = 0;
        

        public boolean isMaceDefending = false;
        public int maceDefenseCooldown = 0;

        public int enemyCooldown = 0;
        public double lastEnemyDist = 99;
        public int shieldFlickerTicks = 0;
        public int shieldPredictTicks = 0;
        public int shieldHoldTicks = 0;
        public int shieldHitTicks = 0;
        public int critFallTicks = 0;
        public int strafeCooldown = 0;
        public int strafeDir = 1;
        
        public enum WeaponMode {
            MELEE,
            RANGED,
            MACE,
            SPEAR,
            CRYSTAL,
            ANCHOR
        }
    }
    
    // ========== ELYTRA MACE TEST ==========

    public static class ElytraMaceState {
        public String targetName;
        public int phase = 0;
        public int tickCounter = 0;
        public int totalTicks = 0;
        public double phaseStartY = 0;
        public class_1799 savedElytra = class_1799.field_8037;
        public int windBurstDelay = 0;
    }

    private static final Map<String, ElytraMaceState> elytraMaceStates = new HashMap<>();
    private static final Map<String, class_1799> pendingElytraRestore = new HashMap<>();

    public static boolean isElytraMaceActive(String botName) {
        return elytraMaceStates.containsKey(botName);
    }

    public static void startElytraMace(String botName, String targetName) {
        ElytraMaceState state = new ElytraMaceState();
        state.targetName = targetName;
        state.phase = 0;
        state.tickCounter = 0;
        elytraMaceStates.put(botName, state);
    }

    public static void stopElytraMace(String botName) {
        elytraMaceStates.remove(botName);
    }

    // ========== WIND BURST ==========

    public static class WindBurstState {
        public String targetName;
        public int phase = 0;
        public int tickCounter = 0;
    }

    private static final Map<String, WindBurstState> windBurstStates = new HashMap<>();

    public static boolean isWindBurstActive(String botName) {
        return windBurstStates.containsKey(botName);
    }

    public static void startWindBurst(String botName, String targetName) {
        WindBurstState state = new WindBurstState();
        state.targetName = targetName;
        state.phase = 0;
        state.tickCounter = 0;
        windBurstStates.put(botName, state);
    }

    private static boolean hasWindBurstMace(class_3222 bot) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = bot.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_49814) {
                var enchantments = stack.method_58694(class_9334.field_49633);
                if (enchantments != null) {
                    for (var entry : enchantments.method_57534()) {
                        String id = entry.method_55840().toLowerCase();
                        if (id.contains("wind_burst")) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public static CombatState getState(String botName) {
        return combatStates.computeIfAbsent(botName, k -> new CombatState());
    }
    
    public static void removeState(String botName) {
        combatStates.remove(botName);
    }
    
    
    public static void update(class_3222 bot, net.minecraft.server.MinecraftServer server) {
        String botName = bot.method_5477().getString();

        if (pendingElytraRestore.containsKey(botName)) {
            if (bot.method_24828() || bot.method_6032() <= 0) {
                class_1799 elytra = pendingElytraRestore.remove(botName);
                if (!elytra.method_7960()) {
                    var inv = bot.method_31548();
                    boolean placed = false;
                    if (inv.method_5438(38).method_7960()) {
                        inv.method_5447(38, elytra.method_7972());
                        placed = true;
                    }
                    if (!placed) {
                        for (int i = 0; i < 41; i++) {
                            if (inv.method_5438(i).method_7960()) {
                                inv.method_5447(i, elytra.method_7972());
                                placed = true;
                                break;
                            }
                        }
                    }
                    if (!placed) {
                        bot.method_7329(elytra.method_7972(), true, true);
                    }
                }
                if (bot.method_5805() && !windBurstStates.containsKey(botName)) {
                    CombatState st = getState(botName);
                    if (st.forcedTargetName != null) {
                        class_1297 t = server.method_3760().method_14566(st.forcedTargetName);
                        if (t != null && t.method_5805() && hasElytraMaceItems(bot)) {
                            startElytraMace(botName, st.forcedTargetName);
                        }
                    }
                }
            }
        }

        // Handle Wind Burst before Elytra Mace
        if (windBurstStates.containsKey(botName)) {
            handleWindBurst(bot, server);
            return;
        }

        if (!elytraMaceStates.containsKey(botName) && !pendingElytraRestore.containsKey(botName) && !windBurstStates.containsKey(botName)) {
            CombatState st = getState(botName);
            String targetName = null;
            if (st.lastAttacker instanceof class_1657 && st.lastAttacker.method_5805() && System.currentTimeMillis() - st.lastAttackTime < 2000) {
                targetName = st.lastAttacker.method_5477().getString();
            } else if (st.forcedTargetName != null) {
                class_1297 forced = server.method_3760().method_14566(st.forcedTargetName);
                if (forced != null && forced.method_5805()) {
                    targetName = st.forcedTargetName;
                }
            }
            if (targetName != null && hasElytraMaceItems(bot)) {
                startElytraMace(botName, targetName);
            }
        }

        // Handle Elytra Mace Test before normal combat
        if (elytraMaceStates.containsKey(botName)) {
            handleElytraMace(bot, server);
            return;
        }

        BotSettings settings = BotSettings.get();
        if (!settings.isCombatEnabled()) return;
        
        CombatState state = getState(bot.method_5477().getString());
        

        float currentHealth = bot.method_6032();
        if (currentHealth < state.lastHealth && settings.isRevengeEnabled()) {

            class_1297 attacker = bot.method_6065();
            if (attacker != null && attacker != bot && attacker instanceof class_1309) {
                state.lastAttacker = attacker;
                state.lastAttackTime = System.currentTimeMillis();
            }
        }
        state.lastHealth = currentHealth;
        

        if (state.attackCooldown > 0) {
            state.attackCooldown--;
        }
        if (state.shieldToggleCooldown > 0) {
            state.shieldToggleCooldown--;
        }
        if (state.cobwebCooldown > 0) {
            state.cobwebCooldown--;
        }
        if (state.crystalCooldown > 0) {
            state.crystalCooldown--;
        }
        

        class_1297 target = findTarget(bot, state, settings, server);
        state.target = target;
        

        

        if (state.isPlacingCobweb && target != null) {
            handleCobwebPlacement(bot, target, state, server);
            return;
        }
        
        if (target == null) {

            if (state.isDrawingBow) {
                stopUsingBow(bot, state);
            }

            BotNavigation.idleWander(bot);
            return;
        }
        

        BotNavigation.resetIdle(bot.method_5477().getString());
        

        double distance = bot.method_5739(target);
        

        float health = bot.method_6032();
        float maxHealth = bot.method_6063();
        float healthPercent = health / maxHealth;
        boolean lowHealth = healthPercent <= settings.getRetreatHealthPercent();
        boolean criticalHealth = healthPercent <= settings.getCriticalHealthPercent();
        
        boolean enemyHealing = isEnemyHealing(target);
        boolean attackWhileEnemyHeals = settings.isAttackWhileEnemyHeals() && enemyHealing;
        boolean healLowHealth = attackWhileEnemyHeals ? health <= 2.0f : lowHealth;
        boolean healCriticalHealth = attackWhileEnemyHeals ? health <= 2.0f : criticalHealth;
        

        boolean hasFood = BotUtils.hasFood(bot);
        

        if (state.shieldBroken && System.currentTimeMillis() - state.shieldBrokenTime > 5000) {
            state.shieldBroken = false;
        }
        

        var utilsState = BotUtils.getState(bot.method_5477().getString());
        
        if (utilsState.healRetreatTicks > 0) {
            return;
        }
        
        if (utilsState.isEscapingCobweb) {
            return;
        }
        
        if (utilsState.needsToCollectWater) {
            return;
        }
        
        boolean isEating = utilsState.isEating;
        
        if (isEating && settings.isRetreatEnabled()) {

            state.isRetreating = true;
            if (state.isDrawingBow) {
                stopUsingBow(bot, state);
            }

            BotNavigation.lookAway(bot, target);
            BotNavigation.moveAway(bot, target, 1.2);
            return;
        } else if (isEating) {

            if (state.isDrawingBow) {
                stopUsingBow(bot, state);
            }

        }
        

        if (healLowHealth && settings.isAutoPotionEnabled() && !utilsState.isEating) {
            if (settings.getHealRetreatSeconds() > 0 && utilsState.healRetreatTicks == 0 && BotUtils.hasHealingPotion(bot)) {
                utilsState.healRetreatTicks = settings.getHealRetreatSeconds() * 20;
                return;
            }
            if (BotUtils.tryUseHealingPotion(bot, server)) {

                return;
            }
        }
        




        boolean shouldRetreat = settings.isRetreatEnabled() && hasFood && 
                               (healCriticalHealth || (healLowHealth && !state.shieldBroken));
        


        if (shouldRetreat) {
            state.isRetreating = true;
            

            if (settings.isAutoShieldEnabled() && !(org.stepan1411.pvp_bot.bot.BotSettings.get().isPreferTotem() && org.stepan1411.pvp_bot.bot.BotUtils.hasTotemInInventory(bot))) {
                var inventory = bot.method_31548();

                if (isEnemyHealing(target) && state.isUsingShield) {
                    stopUsingShield(bot, server);
                    state.isUsingShield = false;
                }

                if (!utilsState.isEating && !utilsState.isBlocking && !isShieldOnCooldown(bot) && !isEnemyHealing(target)) {
                    if (org.stepan1411.pvp_bot.bot.BotUtils.shouldUseMainHandShield(bot)) {
                        org.stepan1411.pvp_bot.bot.BotUtils.equipShieldToMainHand(bot);
                    } else {
                        class_1799 offhandItem = bot.method_6079();
                        if (offhandItem.method_7960() || !offhandItem.method_7909().toString().contains("shield")) {
                            int shieldSlot = findShield(inventory);
                            if (shieldSlot >= 0) {
                                class_1799 shield = inventory.method_5438(shieldSlot);
                                class_1799 offhand = inventory.method_5438(40);
                                inventory.method_5447(40, shield);
                                inventory.method_5447(shieldSlot, offhand);
                            }
                        }
                    }
                }

                if (!state.isUsingShield && state.shieldToggleCooldown <= 0) {
                    if (!utilsState.isEating && !utilsState.isBlocking && !isEnemyHealing(target)) {
                        state.isUsingShield = startUsingShield(bot, server);
                    }
                }
            }
            

            if (distance < 25.0) {

                if (settings.isCobwebEnabled() && distance < 8.0 && state.cobwebCooldown <= 0 && !state.isPlacingCobweb) {
                    tryPlaceCobweb(bot, target, server);
                }
                BotNavigation.lookAway(bot, target);
                BotNavigation.moveAway(bot, target, 1.5);
            }

            return;
        }
        
        // === RANGED RETREAT: low HP + no food → back up and use bow ===
        boolean shouldRangedRetreat = settings.isRetreatEnabled() && !hasFood &&
                                      healthPercent < 0.5f && hasRangedWeaponInInventory(bot) &&
                                      settings.isRangedEnabled();
        
        if (shouldRangedRetreat) {
            var inv = bot.method_31548();
            int rangedSlot = findRangedWeapon(inv);
            if (rangedSlot >= 0 && hasArrows(inv)) {
                state.isRetreating = true;
                double safeDist = settings.getRangedOptimalRange();
                if (distance < safeDist - 5) {
                    if (state.isDrawingBow) {
                        stopUsingBow(bot, state);
                    }
                    BotNavigation.lookAway(bot, target);
                    BotNavigation.moveAway(bot, target, 1.3);
                    return;
                }
                state.currentMode = CombatState.WeaponMode.RANGED;
            } else {
                state.isRetreating = false;
            }
        } else {
            state.isRetreating = false;
        }
        
 
        if (utilsState.isMending) {
            return;
        }




        selectWeaponMode(bot, state, distance, settings);
        


        boolean shouldLookAt = !utilsState.isThrowingPotion;
        
        if (shouldLookAt) {
            BotNavigation.lookAt(bot, target);
        }
        

        double maxRange = switch (state.currentMode) {
            case MELEE -> settings.getMeleeRange() * 2;
            case RANGED -> settings.getRangedMaxRange();
            case MACE -> settings.getMaceRange() * 2;
            case SPEAR -> settings.getSpearChargeRange();
            case CRYSTAL -> 10.0;
            case ANCHOR -> 10.0;
        };
        
        if (distance > maxRange) {

            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
            return;
        }
        

        handleMaceDefense(bot, target, settings, server);
        

        switch (state.currentMode) {
            case MELEE -> handleMeleeCombat(bot, target, state, distance, settings, server);
            case RANGED -> handleRangedCombat(bot, target, state, distance, settings, server);
            case MACE -> handleMaceCombat(bot, target, state, distance, settings, server);
            case SPEAR -> handleSpearCombat(bot, target, state, distance, settings, server);
            case CRYSTAL -> {
                boolean handled = BotCrystalPvp.doCrystalPvp(bot, target, settings, server);
                if (!handled) {
                    state.currentMode = CombatState.WeaponMode.MELEE;
                    handleMeleeCombat(bot, target, state, distance, settings, server);
                }
            }
            case ANCHOR -> {
                boolean handled = BotAnchorPvp.doAnchorPvp(bot, target, settings, server);
                if (!handled) {
                    state.currentMode = CombatState.WeaponMode.MELEE;
                    handleMeleeCombat(bot, target, state, distance, settings, server);
                }
            }
        }
    }
    
    
    private static class_1297 findTarget(class_3222 bot, CombatState state, BotSettings settings, net.minecraft.server.MinecraftServer server) {

        if (state.forcedTargetName != null) {
            class_1297 forced = findEntityByName(bot, state.forcedTargetName, server);
            if (forced != null && forced.method_5805()) {
                if (forced instanceof class_1657 player && !settings.isAttackInvincible() && (player.method_7325() || player.method_68878() || player.method_5655())) {
                    state.forcedTargetName = null;
                } else {
                    double dist = bot.method_5739(forced);
                    if (dist <= settings.getMaxTargetDistance()) {
                        return forced;
                    }
                }
            }


        }
        

        if (settings.isRevengeEnabled() && state.lastAttacker != null) {

            if (!state.lastAttacker.method_31481() && state.lastAttacker.method_5805()) {

                if (state.lastAttacker instanceof class_1657 lastPlayer) {
                    if (!settings.isAttackInvincible() && (lastPlayer.method_7325() || lastPlayer.method_68878() || lastPlayer.method_5655())) {
                        state.lastAttacker = null;
                    } else if (!settings.isFriendlyFireEnabled()) {
                        String attackerName = lastPlayer.method_5477().getString();
                        if (BotFaction.areAllies(bot.method_5477().getString(), attackerName)) {
                            state.lastAttacker = null;
                        }
                    }
                }
                
                if (state.lastAttacker != null) {
                    double dist = bot.method_5739(state.lastAttacker);
                    if (dist <= settings.getMaxTargetDistance()) {

                        if (dist <= 10.0) {
                            state.lastAttackTime = System.currentTimeMillis();
                        }
                        return state.lastAttacker;
                    }
                }
            }

            if (state.lastAttacker == null || state.lastAttacker.method_31481() || !state.lastAttacker.method_5805() || 
                System.currentTimeMillis() - state.lastAttackTime >= 30000) {
                state.lastAttacker = null;
            }
        }
        

        if (settings.isFactionsEnabled()) {
            class_1297 factionEnemy = findFactionEnemy(bot, settings, server);
            if (factionEnemy != null) {
                return factionEnemy;
            }
        }
        

        if (settings.isAutoTargetEnabled()) {
            return findNearestEnemy(bot, settings, server);
        }
        
        return null;
    }
    
    
    private static class_1297 findFactionEnemy(class_3222 bot, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        String botName = bot.method_5477().getString();
        String botFaction = BotFaction.getFaction(botName);
        

        if (botFaction == null) return null;
        
        double maxDist = settings.getMaxTargetDistance();
        class_1297 nearest = null;
        double nearestDist = maxDist + 1;
        
        if (server != null) {
            for (var player : server.method_3760().method_14571()) {
                if (player == bot) continue;
                if (!player.method_5805()) continue;
                if (!settings.isAttackInvincible() && (player.method_7325() || player.method_68878() || player.method_5655())) continue;
                
                String targetName = player.method_5477().getString();
                

                if (BotFaction.areEnemies(botName, targetName)) {
                    double dist = bot.method_5739(player);
                    if (dist < nearestDist && dist <= maxDist) {
                        nearestDist = dist;
                        nearest = player;
                    }
                }
            }
        }
        
        return nearest;
    }
    
    private static class_1297 findEntityByName(class_3222 bot, String name, net.minecraft.server.MinecraftServer server) {

        if (server != null) {
            var player = server.method_3760().method_14566(name);
            if (player != null && player != bot) return player;
        }
        

        if (server != null) {
            for (var world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity.method_5477().getString().equalsIgnoreCase(name) && entity != bot) {
                        return entity;
                    }
                }
            }
        }
        return null;
    }
    
    private static class_1297 findNearestEnemy(class_3222 bot, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        double maxDist = settings.getMaxTargetDistance();
        class_238 searchBox = bot.method_5829().method_1014(maxDist);
        
        class_1297 nearest = null;
        double nearestDist = maxDist + 1;
        

        if (server != null) {
            for (var world : server.method_3738()) {
                for (class_1297 entity : world.method_8335(bot, searchBox)) {
                    if (!isValidTarget(bot, entity, settings)) continue;
                    
                    double dist = bot.method_5739(entity);
                    if (dist < nearestDist) {
                        nearestDist = dist;
                        nearest = entity;
                    }
                }
            }
        }
        
        return nearest;
    }
    
    private static boolean isValidTarget(class_3222 bot, class_1297 entity, BotSettings settings) {
        if (entity == bot) return false;
        if (!entity.method_5805()) return false;
        if (!(entity instanceof class_1309 living)) return false;
        
        String botName = bot.method_5477().getString();
        

        if (entity instanceof class_1657 player) {
            if (!settings.isAttackInvincible() && (player.method_7325() || player.method_68878() || player.method_5655())) return false;
            
            String targetName = player.method_5477().getString();
            

            if (settings.isFactionsEnabled()) {

                if (!settings.isFriendlyFireEnabled() && BotFaction.areAllies(botName, targetName)) {
                    return false;
                }

                if (BotFaction.areEnemies(botName, targetName)) {
                    return true;
                }
            }
            

            if (BotManager.getAllBots().contains(targetName)) {
                if (!settings.isTargetOtherBots()) return false;
            } else {
                if (!settings.isTargetPlayers()) return false;
            }
            
            return true;
        }
        

        if (entity instanceof class_1588) {
            return settings.isTargetHostileMobs();
        }
        

        if (living instanceof net.minecraft.class_1308) {
            return settings.isTargetHostileMobs();
        }
        
        return false;
    }

    
    
    private static void selectWeaponMode(class_3222 bot, CombatState state, double distance, BotSettings settings) {
        if (state.isRetreating) return;
        if (state.isDrawingBow && settings.isRangedRetreatOnClose()) return;
        var inventory = bot.method_31548();
        class_1297 target = state.target;
        
        boolean hasMelee = findMeleeWeapon(inventory) >= 0;
        boolean hasRanged = findRangedWeapon(inventory) >= 0;
        boolean hasMace = findMace(inventory) >= 0;
        boolean hasSpear = findSpear(inventory) >= 0;
        
        double meleeRange = settings.getMeleeRange();
        double rangedMinRange = settings.getRangedMinRange();
        double maceRange = settings.getMaceRange();
        double spearRange = settings.getSpearRange();
        

        if (target != null && BotCrystalPvp.canUseCrystalPvp(bot, target, settings)) {
            state.currentMode = CombatState.WeaponMode.CRYSTAL;
        } else if (target != null && BotAnchorPvp.canUseAnchorPvp(bot, target, settings)) {
            state.currentMode = CombatState.WeaponMode.ANCHOR;
        } else if (hasMace && distance <= maceRange && settings.isMaceEnabled()) {
            state.currentMode = CombatState.WeaponMode.MACE;
        } else if (hasSpear && distance <= spearRange && settings.isSpearEnabled()) {
            state.currentMode = CombatState.WeaponMode.SPEAR;
        } else if (!settings.isRangedRetreatOnClose() && hasMelee && distance <= meleeRange * 2) {
            state.currentMode = CombatState.WeaponMode.MELEE;
        } else if (hasRanged && distance > rangedMinRange && settings.isRangedEnabled()) {
            state.currentMode = CombatState.WeaponMode.RANGED;
        } else if (hasSpear && settings.isSpearEnabled()) {
            state.currentMode = CombatState.WeaponMode.SPEAR;
        } else if (hasRanged && settings.isRangedEnabled()) {
            state.currentMode = CombatState.WeaponMode.RANGED;
        } else {
            state.currentMode = CombatState.WeaponMode.MELEE;
        }
    }
    
    
    private static boolean isTargetMaceAttacking(class_1297 target) {
            if (!(target instanceof class_1657 player)) return false;

            // Check if target has mace in main hand
            class_1799 mainHand = player.method_6047();
            boolean hasMace = mainHand.method_7909() == class_1802.field_49814;

            // Check entire inventory: covers the attribute-swap trick
            // (sword in hand, mace swapped 1 tick before the hit)
            if (!hasMace) {
                var inventory = player.method_31548();
                for (int i = 0; i < 36; i++) {
                    if (inventory.method_5438(i).method_7909() == class_1802.field_49814) {
                        hasMace = true;
                        break;
                    }
                }
                if (!hasMace && inventory.method_5438(40).method_7909() == class_1802.field_49814) {
                    hasMace = true;
                }
            }

            if (!hasMace) return false;

            // Check if target is not on ground (in air)
            boolean inAir = !player.method_24828();
            if (!inAir) return false;

            // Check if target is falling (negative Y velocity) - predict earlier for shield bug
            double velocityY = player.method_18798().field_1351;

            // Predict mace attack when player is falling down
            // Use -0.08 threshold to catch falling but still give 10+ ticks warning
            // This compensates for vanilla shield bug where shield needs to be raised earlier
            boolean willAttackSoon = velocityY < -0.08; // Only when actually falling

            return willAttackSoon;
        }

    
    
    private static void handleMaceDefense(class_3222 bot, class_1297 target, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        if (!settings.isShieldMace()) {
            return;
        }
        
        var inventory = bot.method_31548();
        var utilsState = BotUtils.getState(bot.method_5477().getString());
        var combatState = getState(bot.method_5477().getString());
        

        if (combatState.maceDefenseCooldown > 0) {
            combatState.maceDefenseCooldown--;
        }
        
        boolean isMaceAttacking = isTargetMaceAttacking(target);
        
        if (isMaceAttacking) {

            combatState.maceDefenseCooldown = 20;
            combatState.isMaceDefending = true;
        }
        
        if (isShieldOnCooldown(bot)) {
            combatState.isMaceDefending = false;
        }
        

        boolean shouldDefend = combatState.isMaceDefending && combatState.maceDefenseCooldown > 0;
        
        if (!shouldDefend) {

            if (combatState.isUsingShield && combatState.isMaceDefending) {
                try {
                    server.method_3734().method_9235().execute(
                        "player " + bot.method_5477().getString() + " stop", 
                        server.method_3739()
                    );
                } catch (Exception e) {
                    bot.method_6021();
                }
                if (org.stepan1411.pvp_bot.bot.BotUtils.shouldUseMainHandShield(bot)) {
                    org.stepan1411.pvp_bot.bot.BotUtils.unequipShieldFromMainHand(bot);
                }
                combatState.isUsingShield = false;
                combatState.isMaceDefending = false;
            }
            return;
        }
        

        if (!utilsState.isEating) {
            if (org.stepan1411.pvp_bot.bot.BotUtils.shouldUseMainHandShield(bot)) {
                org.stepan1411.pvp_bot.bot.BotUtils.equipShieldToMainHand(bot);
            } else {
                int shieldSlot = findShield(inventory);
                if (shieldSlot < 0) {
                    return;
                }

                if (shieldSlot != 40) {
                    class_1799 shield = inventory.method_5438(shieldSlot);
                    class_1799 current = inventory.method_5438(40);
                    inventory.method_5447(shieldSlot, current);
                    inventory.method_5447(40, shield);
                }
            }
        }

        if (!combatState.isUsingShield) {
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use continuous", 
                    server.method_3739()
                );
            } catch (Exception e) {
                bot.method_6019(class_1268.field_5810);
            }
            combatState.isUsingShield = true;
        }
    }
    
    
    private static void handleMeleeCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        var utilsState = BotUtils.getState(bot.method_5477().getString());
        
 
        if (state.isUsingShield && !bot.method_6039()) {
            state.isUsingShield = false;
        }
        
        if (state.isMaceDefending && state.maceDefenseCooldown > 0) {
 
            lookAtTarget(bot, target);
            return;
        }
        
        if (utilsState.isEating) {
            System.out.println("[COMBAT] " + bot.method_5477().getString() + " is eating, skipping combat");
            return;
        }
        
        var inventory = bot.method_31548();
        

        if (state.isDrawingBow) {
            stopUsingBow(bot, state);
        }
        
        double meleeRange = settings.getMeleeRange();
        double reach = Math.min(meleeRange, 3.0);
        

        if (settings.isCobwebEnabled() && distance < 6.0 && distance > 2.0 && state.cobwebCooldown <= 0 && !state.isPlacingCobweb) {

            if (target instanceof net.minecraft.class_1309 living) {
                class_243 targetVel = living.method_18798();
                double targetSpeed = Math.sqrt(targetVel.field_1352 * targetVel.field_1352 + targetVel.field_1350 * targetVel.field_1350);
                if (targetSpeed > 0.08) {
                    tryPlaceCobweb(bot, target, server);
                }
            }
        }
        

        var navState = BotNavigation.getState(bot.method_5477().getString());

        boolean enemyHealing = isEnemyHealing(target);
        boolean backOffEnemyHeal = enemyHealing && !settings.isAttackWhileEnemyHeals();

        if (backOffEnemyHeal) {
            if (distance < 3.0) {
                BotNavigation.lookAway(bot, target);
                BotNavigation.moveAway(bot, target, 1.2);
            }
        } else if (distance > reach) {
            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
        } else if (distance < 1.5) {

            BotNavigation.moveAway(bot, target, 0.3);
        } else if (state.attackCooldown > 0 && !navState.wtapActive) {
            bot.method_5728(false);
        }

        if (navState.wtapActive && bot.method_24828()) {
            navState.wtapActive = false;
            bot.method_5728(false);
        }
        

        // === ENEMY ATTACK PREDICTION ===
        if (target instanceof class_3222 enemy) {
            state.enemyCooldown--;
            if (state.enemyCooldown < 0) state.enemyCooldown = 0;
            double enemyDist = bot.method_5739(enemy);
            boolean enemyClosing = enemyDist < state.lastEnemyDist;
            state.lastEnemyDist = enemyDist;
            boolean enemySprinting = enemy.method_5624();
            boolean inMelee = distance <= meleeRange + 1;

            // Enemy sprinting toward + in range + distance decreasing = about to attack
            if (inMelee && enemySprinting && enemyClosing && state.enemyCooldown <= 0) {
                state.shieldPredictTicks = settings.getShieldRaiseTicks();
                state.shieldHoldTicks = Math.max(6, settings.getShieldRaiseTicks() / 2);
                state.enemyCooldown = 15 + random.nextInt(10);
            }
        }
        if (state.shieldPredictTicks > 0) state.shieldPredictTicks--;
        if (state.shieldFlickerTicks > 0) state.shieldFlickerTicks--;
        if (state.shieldHoldTicks > 0) state.shieldHoldTicks--;

        float healthPercent = bot.method_6032() / bot.method_6063();
        boolean lowHealth = healthPercent < settings.getShieldHealthThreshold();
        boolean willAttack = distance <= reach && state.attackCooldown == 1;

        // Combat shield management (predicts attacks, equips shield)
        boolean isEating = utilsState.isEating;
        boolean holdShield = false;
        if (state.shieldPredictTicks > 0 || state.shieldHoldTicks > 0) {
            holdShield = true;
        } else if (!willAttack && lowHealth) {
            holdShield = true;
        } else if (!willAttack && healthPercent < 0.8f && random.nextFloat() < 0.004f && state.shieldToggleCooldown <= 0) {
            holdShield = true;
            state.shieldFlickerTicks = 3 + random.nextInt(3);
        }
        if (state.shieldFlickerTicks > 0) holdShield = true;
        
        if (isShieldOnCooldown(bot)) {
            holdShield = false;
        }
        
        if (enemyHealing) {
            holdShield = false;
        }

        if (org.stepan1411.pvp_bot.bot.BotSettings.get().isPreferTotem() && org.stepan1411.pvp_bot.bot.BotUtils.hasTotemInInventory(bot)) {
            holdShield = false;
        }

        boolean shieldInMainHand = holdShield && org.stepan1411.pvp_bot.bot.BotUtils.shouldUseMainHandShield(bot);

        // Equip shield: main hand (slot 1) when totemPriority, else offhand
        boolean hasShieldInOffhand = bot.method_6079().method_7909() == class_1802.field_8255;
        if (holdShield && !hasShieldInOffhand && !isEating) {
            if (org.stepan1411.pvp_bot.bot.BotUtils.shouldUseMainHandShield(bot)) {
                org.stepan1411.pvp_bot.bot.BotUtils.equipShieldToMainHand(bot);
            } else {
                int shieldSlot = findShield(inventory);
                if (shieldSlot >= 0) {
                    class_1799 shield = inventory.method_5438(shieldSlot);
                    class_1799 offhand = inventory.method_5438(40);
                    inventory.method_5447(40, shield);
                    inventory.method_5447(shieldSlot, offhand);
                }
            }
        }

        // Toggle shield (only when autoShield is NOT active to avoid double-toggling)
        boolean autoShieldActive = settings.isAutoShieldEnabled() && utilsState.isBlocking;
        if (!autoShieldActive) {
            if (holdShield && !state.isUsingShield && state.shieldToggleCooldown <= 0) {
                if (!isEating) {
                    if (startUsingShield(bot, server)) {
                        state.isUsingShield = true;
                    }
                    state.shieldToggleCooldown = 5;
                }
            } else if (!holdShield && state.isUsingShield && state.shieldToggleCooldown <= 0) {
                stopUsingShield(bot, server);
                state.isUsingShield = false;
                state.shieldToggleCooldown = 5;
            }
        }

        // Restore main hand when not holding shield and totemPriority
        if (!holdShield && org.stepan1411.pvp_bot.bot.BotUtils.shouldUseMainHandShield(bot) && !isEating && !autoShieldActive) {
            org.stepan1411.pvp_bot.bot.BotUtils.unequipShieldFromMainHand(bot);
        }

        // === SHIELD BREAK while both block (chance every tick) ===
        if (settings.isShieldBreakEnabled() && state.attackCooldown <= 0 && distance <= reach &&
            target instanceof class_1657 blockPlayer && blockPlayer.method_6039() && (state.isUsingShield || bot.method_6039())) {
            if (random.nextInt(100) < settings.getShieldBreakChance()) {
                if (state.isUsingShield) {
                    stopUsingShield(bot, server);
                    state.isUsingShield = false;
                }
                state.shieldToggleCooldown = 10;
                int axeSlot = findAxe(inventory);
                if (axeSlot >= 0) {
                    if (axeSlot >= 9) {
                        class_1799 axe = inventory.method_5438(axeSlot);
                        class_1799 current = inventory.method_5438(0);
                        inventory.method_5447(axeSlot, current);
                        inventory.method_5447(0, axe);
                        axeSlot = 0;
                    }
                    org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, axeSlot);
                    if (attackWithCarpet(bot, target, server)) {
                        state.shieldBroken = true;
                        state.shieldBrokenTime = System.currentTimeMillis();
                    }
                    state.attackCooldown = lowHealth ? (int)(settings.getAttackCooldown() * 1.5) : settings.getAttackCooldown();
                    return;
                }
            }
        }

        if (distance <= reach && state.attackCooldown <= 0 && !backOffEnemyHeal) {
            if (bot.method_6039() && state.shieldPredictTicks > 0 && distance < 2.0) {
                return;
            }

            if (bot.method_7261(0.5f) < 0.75f) {
                if (settings.isCriticalsEnabled() && bot.method_24828() && bot.method_7261(0.5f) < 0.5f) {
                    bot.method_6043();
                    state.critFallTicks = 0;
                }
                return;
            }
            

            // === SHIELD BREAK (every 2 ticks while enemy blocks) ===
            if (settings.isShieldBreakEnabled() && target instanceof class_1657 player && player.method_6039()) {
                state.shieldHitTicks++;
                if (state.shieldHitTicks % 2 == 0 && random.nextInt(100) < settings.getShieldBreakChance()) {
                    int axeSlot = findAxe(inventory);
                    if (axeSlot >= 0) {
                        if (axeSlot >= 9) {
                            class_1799 axe = inventory.method_5438(axeSlot);
                            class_1799 current = inventory.method_5438(0);
                            inventory.method_5447(axeSlot, current);
                            inventory.method_5447(0, axe);
                            axeSlot = 0;
                        }
                        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, axeSlot);
                        if (attackWithCarpet(bot, target, server)) {
                            state.shieldBroken = true;
                            state.shieldBrokenTime = System.currentTimeMillis();
                        }
                        int cooldown = lowHealth ? (int)(settings.getAttackCooldown() * 1.5) : settings.getAttackCooldown();
                        state.attackCooldown = cooldown;
                        state.shieldHitTicks = 0;
                        return;
                    }
                }
            } else {
                state.shieldHitTicks = 0;
            }
            

            if (!shieldInMainHand) {
                int currentSlot = org.stepan1411.pvp_bot.utils.InventoryHelper.getSelectedSlot(inventory);
                class_1799 currentItem = inventory.method_5438(currentSlot);
                double currentScore = getMeleeScore(currentItem.method_7909(), settings.isPreferSword());
                
                int weaponSlot = findMeleeWeapon(inventory);
                if (weaponSlot >= 0 && weaponSlot < 9) {

                    class_1799 newWeapon = inventory.method_5438(weaponSlot);
                    double newScore = getMeleeScore(newWeapon.method_7909(), settings.isPreferSword());
                    
                    if (newScore > currentScore || currentScore == 0) {
                        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, weaponSlot);
                    }
                }
            }
            

            if (settings.isCriticalsEnabled() && !bot.method_24828() && bot.method_18798().field_1351 < 0 && state.critFallTicks > 0) {
                state.critFallTicks++;
                if (state.critFallTicks >= Math.min(settings.getCriticalFallTicks(), 3) || bot.method_7261(0.5f) >= 0.75f) {
                    bot.field_6017 = 1.0f;
                    attack(bot, target);
                    state.critFallTicks = 0;
                    int cooldown = lowHealth ? (int)(settings.getAttackCooldown() * 1.5) : settings.getAttackCooldown();
                    state.attackCooldown = cooldown;
                }
            } else {
                attackWithCarpet(bot, target, server);
                state.critFallTicks = 0;
                
                int cooldown = lowHealth ? (int)(settings.getAttackCooldown() * 1.5) : settings.getAttackCooldown();
                state.attackCooldown = cooldown;
            }
        } else {

            if (!shieldInMainHand) {
                int currentSlot = org.stepan1411.pvp_bot.utils.InventoryHelper.getSelectedSlot(inventory);
                class_1799 currentItem = inventory.method_5438(currentSlot);
                double currentScore = getMeleeScore(currentItem.method_7909(), settings.isPreferSword());
                
                int weaponSlot = findMeleeWeapon(inventory);
                if (weaponSlot >= 0 && weaponSlot < 9) {

                    class_1799 newWeapon = inventory.method_5438(weaponSlot);
                    double newScore = getMeleeScore(newWeapon.method_7909(), settings.isPreferSword());
                    
                    if (newScore > currentScore || currentScore == 0) {
                        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, weaponSlot);
                    }
                }
            }
        }
    }
    
    
    private static void handleRangedCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings, net.minecraft.server.MinecraftServer server) {


        if (state.isMaceDefending && state.maceDefenseCooldown > 0) {
            lookAtTarget(bot, target);
            return;
        }

        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (utilsState.isEating) {
            return;
        }
        

        if (distance <= settings.getMeleeRange()) {
            if (settings.isRangedRetreatOnClose()) {
                double dx = bot.method_23317() - target.method_23317();
                double dz = bot.method_23321() - target.method_23321();
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > 0) {
                    dx /= dist;
                    dz /= dist;
                    bot.method_5762(dx * settings.getMoveSpeed() * 0.15, 0, dz * settings.getMoveSpeed() * 0.15);
                }
            } else if (findMeleeWeapon(bot.method_31548()) >= 0) {
                if (state.isDrawingBow) {
                    stopUsingBow(bot, state);
                }
                state.currentMode = CombatState.WeaponMode.MELEE;
                return;
            }
        }
        
        var inventory = bot.method_31548();
        

        int bowSlot = findRangedWeapon(inventory);
        if (bowSlot >= 0 && bowSlot < 9) {
            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, bowSlot);
        }
        

        if (!hasArrows(inventory)) {

            state.currentMode = CombatState.WeaponMode.MELEE;
            return;
        }
        
        class_1799 weapon = bot.method_6047();
        boolean isCrossbow = weapon.method_7909() instanceof class_1764;
        
        if (isCrossbow) {
            handleCrossbowCombat(bot, target, state, distance, settings);
        } else {
            handleBowCombat(bot, target, state, distance, settings);
        }
        

        if (settings.isRangedStrafeEnabled()) {
            state.strafeCooldown--;
            if (state.strafeCooldown <= 0) {
                state.strafeDir = -state.strafeDir;
                state.strafeCooldown = 20 + random.nextInt(20);
            }
            bot.field_6212 = (float) (settings.getMoveSpeed() * 0.6 * state.strafeDir);
        }

        double minRange = settings.getRangedMinRange();
        if (state.isRetreating) {
            double safeDist = settings.getRangedOptimalRange();
            if (distance < safeDist) {
                double dx = bot.method_23317() - target.method_23317();
                double dz = bot.method_23321() - target.method_23321();
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > 0) {
                    dx /= dist;
                    dz /= dist;
                    bot.method_5762(dx * settings.getMoveSpeed() * 0.05, 0, dz * settings.getMoveSpeed() * 0.05);
                }
            }
        } else if (distance < minRange) {

            double dx = bot.method_23317() - target.method_23317();
            double dz = bot.method_23321() - target.method_23321();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > 0) {
                dx /= dist;
                dz /= dist;
                bot.method_5762(dx * settings.getMoveSpeed() * 0.05, 0, dz * settings.getMoveSpeed() * 0.05);

            }
        } else if (distance > minRange + 2) {
            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
        }
    }
    
    private static void handleBowCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings) {
        if (!state.isDrawingBow) {

            bot.method_6019(class_1268.field_5808);
            state.isDrawingBow = true;
            state.bowDrawTicks = 0;
        } else {
            state.bowDrawTicks++;
            

            float drawProgress = Math.min(1.0f, state.bowDrawTicks / 20.0f);
            lookAtTargetWithPrediction(bot, target, drawProgress, settings);

            int minDrawTime = settings.getBowMinDrawTime();
            if (state.bowDrawTicks >= minDrawTime) {

                lookAtTargetWithPrediction(bot, target, drawProgress, settings);
                bot.method_6075();
                state.isDrawingBow = false;
                state.bowDrawTicks = 0;
                state.attackCooldown = 5;
            }
        }
    }
    
    private static void handleCrossbowCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings) {
        class_1799 crossbow = bot.method_6047();
        
        if (class_1764.method_7781(crossbow)) {

            lookAtTargetWithPrediction(bot, target, 1.0f, settings);
            bot.method_6075();
            state.attackCooldown = 5;
            state.isDrawingBow = false;
        } else if (!state.isDrawingBow) {

            bot.method_6019(class_1268.field_5808);
            state.isDrawingBow = true;
            state.bowDrawTicks = 0;
        } else {
            state.bowDrawTicks++;

            if (state.bowDrawTicks >= 25) {
                lookAtTargetWithPrediction(bot, target, 1.0f, settings);
                bot.method_6075();
                state.isDrawingBow = false;
            }
        }
    }
    
    private static void stopUsingBow(class_3222 bot, CombatState state) {
        if (state.isDrawingBow) {
            bot.method_6075();
            state.isDrawingBow = false;
            state.bowDrawTicks = 0;
        }
    }
    
    
    private static void handleMaceCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings, net.minecraft.server.MinecraftServer server) {


        if (state.isMaceDefending && state.maceDefenseCooldown > 0) {
            lookAtTarget(bot, target);
            return;
        }

        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (utilsState.isEating) {
            return;
        }
        
        var inventory = bot.method_31548();
        
        if (state.isDrawingBow) {
            stopUsingBow(bot, state);
        }
        

        if (!bot.method_24828()) {
            int maceSlot = findMace(inventory);
            if (maceSlot >= 0 && maceSlot < 9) {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, maceSlot);
            }
            


            double verticalSpeed = bot.method_18798().field_1351;
            if (verticalSpeed < 0 && distance <= 5.0 && state.attackCooldown <= 0) {

                attackWithCarpet(bot, target, server);
                state.attackCooldown = 1;
            }
            return;
        }
        

        if (bot.method_24828() && distance <= settings.getMaceRange()) {

            int windChargeSlot = findWindCharge(inventory);
            
            if (windChargeSlot >= 0) {

                BotUtils.useWindCharge(bot, server);
                bot.method_6043();
            } else {

                int maceSlot = findMace(inventory);
                if (maceSlot >= 0 && maceSlot < 9) {
                    org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, maceSlot);
                }
                
                bot.method_6043();
                double dx = target.method_23317() - bot.method_23317();
                double dz = target.method_23321() - bot.method_23321();
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > 0) {
                    dx /= dist;
                    dz /= dist;
                }
                bot.method_5762(dx * 0.3, 0.3, dz * 0.3);
            }
        }
        

        if (bot.method_24828() && distance <= 3.5 && state.attackCooldown <= 0) {
            int maceSlot = findMace(inventory);
            if (maceSlot >= 0 && maceSlot < 9) {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, maceSlot);
            }
            attackWithCarpet(bot, target, server);
            state.attackCooldown = settings.getAttackCooldown();
        }
        

        if (distance > settings.getMaceRange()) {
            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
        }
    }
    
    
    private static void handleSpearCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings, net.minecraft.server.MinecraftServer server) {


        if (state.isMaceDefending && state.maceDefenseCooldown > 0) {
            lookAtTarget(bot, target);
            return;
        }

        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (utilsState.isEating) {
            return;
        }
        
        var inventory = bot.method_31548();
        

        if (state.isDrawingBow) {
            stopUsingBow(bot, state);
        }
        

        int spearSlot = findSpear(inventory);
        if (spearSlot >= 0 && spearSlot < 9) {
            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, spearSlot);
        }
        
        double chargeStartDistance = 10.0;
        double chargeHitDistance = 0.1;
        





        
        if (distance > chargeStartDistance) {

            if (state.isChargingSpear) {
                bot.method_6075();
                state.isChargingSpear = false;
                state.spearChargeTicks = 0;
            }
            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
            
        } else if (distance > chargeHitDistance) {

            if (!state.isChargingSpear) {

                bot.method_6019(class_1268.field_5808);
                state.isChargingSpear = true;
                state.spearChargeTicks = 0;
            }
            
            state.spearChargeTicks++;
            

            BotNavigation.moveToward(bot, target, settings.getMoveSpeed() * 1.3);
            

            if (state.spearChargeTicks > 60) {

                bot.method_6075();
                state.isChargingSpear = false;
                state.spearChargeTicks = 0;
            }
            
        } else {

            if (state.isChargingSpear) {

                bot.method_6075();
                state.isChargingSpear = false;
                state.spearChargeTicks = 0;

                state.attackCooldown = 0;
            }
            

            BotNavigation.moveAway(bot, target, settings.getMoveSpeed());
        }
    }

    
    private static final java.util.Random random = new java.util.Random();
    
    
    private static void attack(class_3222 bot, class_1297 target) {
        BotSettings settings = BotSettings.get();
        

        if (random.nextInt(100) < settings.getMissChance()) {

            bot.method_6104(class_1268.field_5808);
            return;
        }
        
        bot.method_7324(target);
        bot.method_6104(class_1268.field_5808);
        BotNavigation.startWtap(bot.method_5477().getString());
    }
    
    
    private static boolean attackWithCarpet(class_3222 bot, class_1297 target, net.minecraft.server.MinecraftServer server) {
        BotSettings settings = BotSettings.get();
        
        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (!BotUtils.canAttack(bot, utilsState)) {
            System.out.println("[COMBAT] " + bot.method_5477().getString() + " cannot attack - cobweb escape active");
            bot.method_6104(class_1268.field_5808);
            return false;
        }



        if (!settings.isFriendlyFireEnabled() && target instanceof class_1657) {
            String botName = bot.method_5477().getString();
            String targetName = target.method_5477().getString();
            if (BotFaction.areAllies(botName, targetName)) {
                System.out.println("[COMBAT] " + bot.method_5477().getString() + " skipping ally " + targetName);
                bot.method_6104(class_1268.field_5808);
                return false;
            }
        }
        

        if (random.nextInt(100) < settings.getMissChance()) {
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " swinghand", 
                    server.method_3739()
                );
            } catch (Exception e) {
                bot.method_6104(class_1268.field_5808);
            }
            return false;
        }
        

        if (random.nextInt(100) < settings.getMistakeChance()) {
            float yawOffset = (random.nextFloat() - 0.5f) * 60;
            bot.method_36456(bot.method_36454() + yawOffset);
        }
        

        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " attack once", 
                server.method_3739()
            );
            BotNavigation.startWtap(bot.method_5477().getString());
            return true;
        } catch (Exception e) {
            bot.method_6104(class_1268.field_5808);
            return false;
        }
    }
    
    
    static boolean isShieldOnCooldown(class_3222 bot) {
        return bot.method_7357().method_7904(new class_1799(class_1802.field_8255));
    }
    
    static boolean isEnemyHealing(class_1297 target) {
        if (!(target instanceof class_1309 living)) return false;
        if (!living.method_6115()) return false;
        class_1799 active = living.method_6030();
        if (active.method_7960()) return false;
        if (active.method_7909().method_57347().method_58694(class_9334.field_50075) != null) return true;
        return active.method_7909() instanceof class_1812;
    }
    
    private static boolean startUsingShield(class_3222 bot, net.minecraft.server.MinecraftServer server) {
        if (isShieldOnCooldown(bot)) {
            return false;
        }
        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " use continuous", 
                server.method_3739()
            );
            return true;
        } catch (Exception e) {

            bot.method_6019(class_1268.field_5810);
            return false;
        }
    }
    
    
    private static void stopUsingShield(class_3222 bot, net.minecraft.server.MinecraftServer server) {
        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " stop", 
                server.method_3739()
            );
        } catch (Exception e) {

            bot.method_6021();
        }
    }
    
    
    private static void lookAtTarget(class_3222 bot, class_1297 target) {
        class_243 targetPos = target.method_33571();
        class_243 botPos = bot.method_33571();
        
        double dx = targetPos.field_1352 - botPos.field_1352;
        double dy = targetPos.field_1351 - botPos.field_1351;
        double dz = targetPos.field_1350 - botPos.field_1350;
        
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) (class_3532.method_15349(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(class_3532.method_15349(dy, horizontalDist) * (180.0 / Math.PI));
        
        bot.method_36456(yaw);
        bot.method_36457(pitch);
        bot.method_5847(yaw);
    }
    
    
    private static void lookAwayFromTarget(class_3222 bot, class_1297 target) {
        class_243 targetPos = target.method_33571();
        class_243 botPos = bot.method_33571();
        

        double dx = botPos.field_1352 - targetPos.field_1352;
        double dz = botPos.field_1350 - targetPos.field_1350;
        
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) (class_3532.method_15349(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        
        bot.method_36456(yaw);
        bot.method_36457(0);
        bot.method_5847(yaw);
    }
    
    
    private static void lookAtTargetWithPrediction(class_3222 bot, class_1297 target, float drawProgress, BotSettings settings) {
        if (!settings.isArrowPredictionEnabled()) {
            lookAtTarget(bot, target);
            return;
        }

        double arrowSpeed = Math.max(0.5, drawProgress * 3.0);

        class_243 botPos = bot.method_33571();
        class_243 targetPos = target.method_33571();
        class_243 targetVel = target.method_18798();

        double dx = targetPos.field_1352 - botPos.field_1352;
        double dy = targetPos.field_1351 - botPos.field_1351;
        double dz = targetPos.field_1350 - botPos.field_1350;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);

        double effectiveSpeed = arrowSpeed * 0.95;
        if (effectiveSpeed <= 0) effectiveSpeed = 1.0;

        double flightTime = distance / effectiveSpeed;
        flightTime = Math.min(flightTime, 60);

        double px = targetPos.field_1352 + targetVel.field_1352 * flightTime;
        double py = targetPos.field_1351 + targetVel.field_1351 * flightTime;
        double pz = targetPos.field_1350 + targetVel.field_1350 * flightTime;

        double gravityDrop = 0.5 * 0.05 * flightTime * flightTime;
        py += gravityDrop;

        double aimDx = px - botPos.field_1352;
        double aimDy = py - botPos.field_1351;
        double aimDz = pz - botPos.field_1350;

        double horizontalDist = Math.sqrt(aimDx * aimDx + aimDz * aimDz);

        float yaw = (float) (class_3532.method_15349(aimDz, aimDx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(class_3532.method_15349(aimDy, horizontalDist) * (180.0 / Math.PI));

        bot.method_36456(yaw);
        bot.method_36457(pitch);
        bot.method_5847(yaw);
    }

    private static void moveToward(class_3222 bot, class_1297 target, double speed) {
        double botX = bot.method_23317(), botY = bot.method_23318(), botZ = bot.method_23321();
        double targetX = target.method_23317(), targetY = target.method_23318(), targetZ = target.method_23321();
        double dx = targetX - botX;
        double dz = targetZ - botZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 0) {
            dx /= dist;
            dz /= dist;
        }
        
        bot.method_5728(true);
        bot.field_6250 = (float) speed;
        bot.field_6212 = 0;
        

        if (bot.method_24828()) {
            bot.method_5762(dx * speed * 0.1, 0, dz * speed * 0.1);
        }
    }
    
    
    private static void moveAway(class_3222 bot, class_1297 target, double speed) {
        double botX = bot.method_23317(), botY = bot.method_23318(), botZ = bot.method_23321();
        double targetX = target.method_23317(), targetY = target.method_23318(), targetZ = target.method_23321();
        double dx = botX - targetX;
        double dz = botZ - targetZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 0) {
            dx /= dist;
            dz /= dist;
        }
        

        bot.method_5728(true);
        bot.field_6250 = (float) speed;
        
        if (bot.method_24828()) {
            bot.method_5762(dx * speed * 0.1, 0, dz * speed * 0.1);
        }
    }
    

    
    private static int findMeleeWeapon(net.minecraft.class_1661 inventory) {
        BotSettings settings = BotSettings.get();
        boolean preferSword = settings.isPreferSword();
        
        int bestSlot = -1;
        double bestScore = 0;
        
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            class_1792 item = stack.method_7909();
            double score = getMeleeScore(item, preferSword);
            
            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }
        
        return bestSlot;
    }
    
    
    private static int findAxe(net.minecraft.class_1661 inventory) {
        int bestSlot = -1;
        double bestDamage = 0;
        
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            class_1792 item = stack.method_7909();
            if (item instanceof class_1743) {
                double damage = getAxeDamage(item);
                if (damage > bestDamage) {
                    bestDamage = damage;
                    bestSlot = i;
                }
            }
        }
        
        return bestSlot;
    }
    
    
    private static int findShield(net.minecraft.class_1661 inventory) {

        if (inventory.method_5438(40).method_7909() == class_1802.field_8255) return 40;
        

        for (int i = 0; i < 36; i++) {
            if (inventory.method_5438(i).method_7909() == class_1802.field_8255) return i;
        }
        return -1;
    }
    
    private static double getAxeDamage(class_1792 item) {
        if (item == class_1802.field_22025) return 10;
        if (item == class_1802.field_8556) return 9;
        if (item == class_1802.field_8475) return 9;
        if (item == class_1802.field_8062) return 9;
        if (item == class_1802.field_8825) return 7;
        if (item == class_1802.field_8406) return 7;
        return 0;
    }
    
    
    private static double getMeleeScore(class_1792 item, boolean preferSword) {
        double baseDamage = getMeleeDamage(item);
        if (baseDamage == 0) return 0;
        

        if (preferSword && isSword(item)) {
            return baseDamage + 5;
        }
        
        return baseDamage;
    }
    
    
    private static boolean isSword(class_1792 item) {
        return item == class_1802.field_22022 || 
               item == class_1802.field_8802 || 
               item == class_1802.field_8371 || 
               item == class_1802.field_8845 || 
               item == class_1802.field_8528 || 
               item == class_1802.field_8091;
    }
    
    private static double getMeleeDamage(class_1792 item) {
        if (item == class_1802.field_22022) return 8;
        if (item == class_1802.field_22025) return 10;
        if (item == class_1802.field_8802) return 7;
        if (item == class_1802.field_8556) return 9;
        if (item == class_1802.field_8371) return 6;
        if (item == class_1802.field_8475) return 9;
        if (item == class_1802.field_8528) return 5;
        if (item == class_1802.field_8062) return 9;
        if (item == class_1802.field_8845) return 4;
        if (item == class_1802.field_8825) return 7;
        if (item == class_1802.field_8091) return 4;
        if (item == class_1802.field_8406) return 7;
        if (item == class_1802.field_8547) return 9;
        return 0;
    }
    
    private static int findRangedWeapon(net.minecraft.class_1661 inventory) {

        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() instanceof class_1764) return i;
        }
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() instanceof class_1753) return i;
        }
        return -1;
    }
    
    private static int findMace(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_49814) return i;
        }
        return -1;
    }
    
    private static int findWindCharge(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_49098) return i;
        }
        return -1;
    }
    
    
    private static int findSpear(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);

            String itemName = stack.method_7909().toString().toLowerCase();
            if (itemName.contains("spear")) return i;
        }
        return -1;
    }
    
    
    private static int findCobweb(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8786) return i;
        }
        return -1;
    }
    
    
    private static boolean tryPlaceCobweb(class_3222 bot, class_1297 target, net.minecraft.server.MinecraftServer server) {
        CombatState state = getState(bot.method_5477().getString());
        

        if (state.isPlacingCobweb) return false;
        
        var inventory = bot.method_31548();
        int cobwebSlot = findCobweb(inventory);
        if (cobwebSlot < 0) return false;
        

        var world = bot.method_51469();
        net.minecraft.class_2338 targetPos = target.method_24515();
        if (world.method_8320(targetPos).method_26204() == net.minecraft.class_2246.field_10343) {
            return false;
        }
        

        if (cobwebSlot >= 9) {
            class_1799 cobweb = inventory.method_5438(cobwebSlot);
            class_1799 current = inventory.method_5438(0);
            inventory.method_5447(cobwebSlot, current);
            inventory.method_5447(0, cobweb);
            cobwebSlot = 0;
        }
        

        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, cobwebSlot);
        

        state.isPlacingCobweb = true;
        state.cobwebPlaceTicks = 0;
        
        return true;
    }
    
    
    private static void handleCobwebPlacement(class_3222 bot, class_1297 target, CombatState state, net.minecraft.server.MinecraftServer server) {
        state.cobwebPlaceTicks++;
        

        class_243 targetFeet = new class_243(target.method_23317(), target.method_23318() - 0.5, target.method_23321());
        class_243 botPos = bot.method_33571();
        
        double dx = targetFeet.field_1352 - botPos.field_1352;
        double dy = targetFeet.field_1351 - botPos.field_1351;
        double dz = targetFeet.field_1350 - botPos.field_1350;
        
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) (Math.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(Math.atan2(dy, horizontalDist) * (180.0 / Math.PI));
        
        bot.method_36456(yaw);
        bot.method_36457(pitch);
        bot.method_5847(yaw);
        

        if (state.cobwebPlaceTicks % 2 == 0 && state.cobwebPlaceTicks <= 6) {
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use once", 
                    server.method_3739()
                );
            } catch (Exception e) {

            }
        }
        

        if (state.cobwebPlaceTicks >= 8) {
            state.isPlacingCobweb = false;
            state.cobwebPlaceTicks = 0;
            state.cobwebCooldown = 20;
        }
    }
    
    private static boolean hasArrows(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() instanceof class_1744) return true;
        }
        return false;
    }
    
    private static boolean hasRangedWeaponInInventory(class_3222 bot) {
        var inv = bot.method_31548();
        return findRangedWeapon(inv) >= 0;
    }
    

    
    
    public static void setTarget(String botName, String targetName) {
        CombatState state = getState(botName);
        state.forcedTargetName = targetName;
    }
    
    
    public static void clearTarget(String botName) {
        CombatState state = getState(botName);
        state.forcedTargetName = null;
        state.target = null;
        state.lastAttacker = null;
        state.lastAttackTime = 0;
        state.isRetreating = false;
        elytraMaceStates.remove(botName);
        pendingElytraRestore.remove(botName);
        windBurstStates.remove(botName);
    }
    
    
    public static void onBotDamaged(class_3222 bot, class_1282 source) {

        class_1297 attacker = source.method_5529();
        if (attacker == null) {
            attacker = source.method_5526();
        }
        if (attacker == null || attacker == bot) return;
        

        if (!(attacker instanceof class_1309)) return;
        
        CombatState state = getState(bot.method_5477().getString());
        state.lastAttacker = attacker;
        state.lastAttackTime = System.currentTimeMillis();

        String botName = bot.method_5477().getString();
        if (!elytraMaceStates.containsKey(botName) && !pendingElytraRestore.containsKey(botName) && !windBurstStates.containsKey(botName)) {
            if (attacker instanceof class_1657 && attacker.method_5805() && hasElytraMaceItems(bot)) {
                startElytraMace(botName, attacker.method_5477().getString());
            }
        }
    }
    
    
    public static class_1297 getTarget(String botName) {
        return getState(botName).target;
    }

    // ========== ELYTRA MACE HANDLER ==========

    private static boolean hasElytraMaceItems(class_3222 bot) {
        var inv = bot.method_31548();
        boolean hasElytra = false;
        boolean hasFireworks = false;
        boolean hasMace = false;
        for (int i = 0; i < 41; i++) {
            class_1792 item = inv.method_5438(i).method_7909();
            if (item == class_1802.field_8833) hasElytra = true;
            if (item == class_1802.field_8639) hasFireworks = true;
            if (item == class_1802.field_49814) hasMace = true;
        }
        return hasElytra && hasFireworks && hasMace;
    }

    private static void handleElytraMace(class_3222 bot, net.minecraft.server.MinecraftServer server) {
        String botName = bot.method_5477().getString();
        ElytraMaceState state = elytraMaceStates.get(botName);
        if (state == null) return;

        var inventory = bot.method_31548();
        state.tickCounter++;
        state.totalTicks++;

        if (state.totalTicks > 300) {
            elytraMaceStates.remove(botName);
            return;
        }

        if (state.phase < 6) {
            boolean hasFireworks = false;
            for (int i = 0; i < 41; i++) {
                if (inventory.method_5438(i).method_7909() == class_1802.field_8639) {
                    hasFireworks = true;
                    break;
                }
            }
            if (!hasFireworks) {
                elytraMaceStates.remove(botName);
                return;
            }
        }

        class_1297 currentTarget = server.method_3760().method_14566(state.targetName);
        if (currentTarget == null || !currentTarget.method_5805()) {
            elytraMaceStates.remove(botName);
            return;
        }

        switch (state.phase) {
            case 0: {
                try {
                    server.method_3734().method_9235().execute(
                        "player " + botName + " stop",
                        server.method_3739()
                    );
                } catch (Exception ignored) {}
                for (int i = 0; i < 41; i++) {
                    if (inventory.method_5438(i).method_7909() == class_1802.field_8833) {
                        if (i != 38) {
                            class_1799 elytra = inventory.method_5438(i);
                            class_1799 current38 = inventory.method_5438(38);
                            inventory.method_5447(i, current38);
                            inventory.method_5447(38, elytra);
                        }
                        break;
                    }
                }
                state.phase = 1;
                state.tickCounter = 0;
                break;
            }
            case 1: {
                for (int i = 0; i < 41; i++) {
                    if (inventory.method_5438(i).method_7909() == class_1802.field_8639) {
                        if (i != 0) {
                            class_1799 rocket = inventory.method_5438(i);
                            class_1799 current = inventory.method_5438(0);
                            inventory.method_5447(i, current);
                            inventory.method_5447(0, rocket);
                        }
                        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
                        break;
                    }
                }
                state.phase = 2;
                state.tickCounter = 0;
                break;
            }
            case 2: {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
                bot.method_36457(-90);
                try {
                    server.method_3734().method_9235().execute(
                        "player " + botName + " jump once",
                        server.method_3739()
                    );
                } catch (Exception ignored) {}
                state.phaseStartY = bot.method_23318();
                state.phase = 3;
                state.tickCounter = 0;
                break;
            }
            case 3: {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
                if (state.tickCounter == 5) {
                    if (bot.method_23318() - state.phaseStartY < 0.3) {
                        elytraMaceStates.remove(botName);
                        return;
                    }
                }
                if (state.tickCounter >= 6) {
                    state.phase = 4;
                    state.tickCounter = 0;
                }
                break;
            }
            case 4: {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
                try {
                    server.method_3734().method_9235().execute(
                        "player " + botName + " jump once",
                        server.method_3739()
                    );
                } catch (Exception ignored) {}
                state.phase = 5;
                state.tickCounter = 0;
                break;
            }
            case 5: {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
                if (state.tickCounter >= 1) {
                    try {
                        server.method_3734().method_9235().execute(
                            "player " + botName + " use once",
                            server.method_3739()
                        );
                    } catch (Exception ignored) {}
                    state.phase = 6;
                    state.tickCounter = 0;
                }
                break;
            }
            case 6: {
                if (state.tickCounter >= 10) {
                    state.phase = 7;
                    state.tickCounter = 0;
                }
                break;
            }
            case 7: {
                state.savedElytra = inventory.method_5438(38).method_7972();
                if (inventory.method_5438(38).method_7909() == class_1802.field_8833) {
                    inventory.method_5447(38, class_1799.field_8037);
                }
                for (int i = 0; i < 41; i++) {
                    class_1799 stack = inventory.method_5438(i);
                    if (stack.method_7960()) continue;
                    class_1792 item = stack.method_7909();
                    boolean isChestplate = item == class_1802.field_22028 ||
                        item == class_1802.field_8058 ||
                        item == class_1802.field_8523 ||
                        item == class_1802.field_8873 ||
                        item == class_1802.field_8678 ||
                        item == class_1802.field_8577;
                    if (isChestplate) {
                        inventory.method_5447(38, stack.method_7972());
                        inventory.method_5447(i, class_1799.field_8037);
                        break;
                    }
                }
                state.phase = 8;
                state.tickCounter = 0;
                break;
            }
            case 8: {
                if (state.tickCounter >= 1) {
                    state.phase = 9;
                    state.tickCounter = 0;
                }
                break;
            }
            case 9: {
                if (!state.savedElytra.method_7960()) {
                    class_1799 current38 = inventory.method_5438(38);
                    boolean isChestplate = current38.method_7909() == class_1802.field_22028 ||
                        current38.method_7909() == class_1802.field_8058 ||
                        current38.method_7909() == class_1802.field_8523 ||
                        current38.method_7909() == class_1802.field_8873 ||
                        current38.method_7909() == class_1802.field_8678 ||
                        current38.method_7909() == class_1802.field_8577;
                    if (isChestplate) {
                        boolean placed = false;
                        for (int i = 0; i < 38; i++) {
                            if (inventory.method_5438(i).method_7960()) {
                                inventory.method_5447(i, current38.method_7972());
                                placed = true;
                                break;
                            }
                        }
                        if (!placed) {
                            bot.method_7329(current38.method_7972(), true, true);
                        }
                    }
                    inventory.method_5447(38, state.savedElytra.method_7972());
                }
                state.phase = 10;
                state.tickCounter = 0;
                break;
            }
            case 10: {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
                if (state.tickCounter >= 2) {
                    try {
                        server.method_3734().method_9235().execute(
                            "player " + botName + " jump once",
                            server.method_3739()
                        );
                    } catch (Exception ignored) {}
                    state.phase = 11;
                    state.tickCounter = 0;
                }
                break;
            }
            case 11: {
                class_1297 targetEntity = server.method_3760().method_14566(state.targetName);
                if (targetEntity != null && targetEntity.method_5805()) {
                    lookAtTarget(bot, targetEntity);
                    BotNavigation.moveToward(bot, targetEntity, 1.0);
                    double dist = bot.method_5739(targetEntity);
                    if (dist <= 8.0) {
                        class_1799 chestSlot = inventory.method_5438(38);
                        if (chestSlot.method_7909() == class_1802.field_8833) {
                            inventory.method_5447(38, class_1799.field_8037);
                            pendingElytraRestore.put(botName, chestSlot.method_7972());
                            int maceSlot = findMace(inventory);
                            if (maceSlot >= 0) {
                                if (maceSlot >= 9) {
                                    class_1799 mace = inventory.method_5438(maceSlot);
                                    class_1799 slot0 = inventory.method_5438(0);
                                    inventory.method_5447(maceSlot, slot0);
                                    inventory.method_5447(0, mace);
                                    maceSlot = 0;
                                }
                                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, maceSlot);
                            }
                            state.windBurstDelay = 0;
                        } else {
                            state.windBurstDelay++;
                            if (state.windBurstDelay >= 3) {
                                lookAtTarget(bot, targetEntity);
                                attackWithCarpet(bot, targetEntity, server);
                                CombatState combatState = getState(botName);
                                combatState.forcedTargetName = state.targetName;
                                if (hasWindBurstMace(bot)) {
                                    startWindBurst(botName, state.targetName);
                                }
                                elytraMaceStates.remove(botName);
                            }
                        }
                    }
                } else {
                    elytraMaceStates.remove(botName);
                }
                break;
            }
        }
    }

    // ========== WIND BURST HANDLER ==========

    private static void handleWindBurst(class_3222 bot, net.minecraft.server.MinecraftServer server) {
        String botName = bot.method_5477().getString();
        WindBurstState state = windBurstStates.get(botName);
        if (state == null) {
            return;
        }

        net.minecraft.class_1661 inventory = bot.method_31548();
        state.tickCounter++;

        if (state.tickCounter > 200) {
            windBurstStates.remove(botName);
            pendingElytraRestore.remove(botName);
            return;
        }

        class_1297 target = server.method_3760().method_14566(state.targetName);
        if (target == null || !target.method_5805()) {
            windBurstStates.remove(botName);
            return;
        }

        switch (state.phase) {
            case 0: {
                if (state.tickCounter >= 10) {
                    state.phase = 1;
                    state.tickCounter = 0;
                }
                break;
            }
            case 1: {
                class_1799 savedElytra = pendingElytraRestore.remove(botName);
                if (savedElytra != null && !savedElytra.method_7960()) {
                    inventory.method_5447(38, savedElytra.method_7972());
                } else {
                    for (int i = 0; i < 41; i++) {
                        if (inventory.method_5438(i).method_7909() == class_1802.field_8833) {
                            if (i != 38) {
                                class_1799 elytra = inventory.method_5438(i);
                                class_1799 current38 = inventory.method_5438(38);
                                inventory.method_5447(i, current38);
                                inventory.method_5447(38, elytra);
                            }
                            break;
                        }
                    }
                }
                try {
                    server.method_3734().method_9235().execute(
                        "player " + botName + " jump once",
                        server.method_3739()
                    );
                } catch (Exception ignored) {}
                state.phase = 2;
                state.tickCounter = 0;
                break;
            }
            case 2: {
                    if (state.tickCounter >= 1) {
                        boolean foundFirework = false;
                        for (int i = 0; i < 41; i++) {
                            if (inventory.method_5438(i).method_7909() == class_1802.field_8639) {
                                if (i != 0) {
                                    class_1799 rocket = inventory.method_5438(i);
                                    class_1799 current = inventory.method_5438(0);
                                    inventory.method_5447(i, current);
                                    inventory.method_5447(0, rocket);
                                }
                                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
                                foundFirework = true;
                                break;
                            }
                        }
                        if (!foundFirework) {
                            windBurstStates.remove(botName);
                            break;
                        }
                        lookAtTarget(bot, target);
                        try {
                            server.method_3734().method_9235().execute(
                                "player " + botName + " use once",
                                server.method_3739()
                            );
                        } catch (Exception ignored) {}
                        state.phase = 3;
                        state.tickCounter = 0;
                    }
                break;
            }
            case 3: {
                double dist = bot.method_5739(target);
                BotNavigation.moveToward(bot, target, 1.0);

                if (dist <= 6.0) {
                    lookAtTarget(bot, target);
                    class_1799 chestSlot = inventory.method_5438(38);
                    if (chestSlot.method_7909() == class_1802.field_8833) {
                        inventory.method_5447(38, class_1799.field_8037);
                        pendingElytraRestore.put(botName, chestSlot.method_7972());

                        int maceSlot = findMace(inventory);
                        if (maceSlot >= 0) {
                            if (maceSlot >= 9) {
                                class_1799 mace = inventory.method_5438(maceSlot);
                                class_1799 slot0 = inventory.method_5438(0);
                                inventory.method_5447(maceSlot, slot0);
                                inventory.method_5447(0, mace);
                                maceSlot = 0;
                            }
                            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, maceSlot);
                        }

                        if (bot.field_6017 < 1.5f) {
                            try {
                                server.method_3734().method_9235().execute(
                                    "player " + botName + " attack once",
                                    server.method_3739()
                                );
                            } catch (Exception ignored) {}
                            windBurstStates.remove(botName);
                            break;
                        }
                    }

                    try {
                        server.method_3734().method_9235().execute(
                            "player " + botName + " attack once",
                            server.method_3739()
                        );
                    } catch (Exception ignored) {}
                } else {
                    BotNavigation.lookAtPosition(bot, new class_243(target.method_23317(), target.method_23318() + 3, target.method_23321()));
                    if (inventory.method_5438(38).method_7909() != class_1802.field_8833) {
                        state.phase = 0;
                        state.tickCounter = 0;
                    }
                }
                break;
            }
        }
    }
}
