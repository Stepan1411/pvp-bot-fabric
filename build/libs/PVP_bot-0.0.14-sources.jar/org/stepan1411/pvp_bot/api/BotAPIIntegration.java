package org.stepan1411.pvp_bot.api;

import net.minecraft.class_1297;
import net.minecraft.class_3222;


public class BotAPIIntegration {
    
    
    public static void fireSpawnEvent(class_3222 bot) {
        try {
            PvpBotAPI.getEventManager().fireSpawnEvent(bot);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing spawn event: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    
    public static void fireDeathEvent(class_3222 bot) {
        try {
            PvpBotAPI.getEventManager().fireDeathEvent(bot);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing death event: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    
    public static boolean fireAttackEvent(class_3222 bot, class_1297 target) {
        try {
            return PvpBotAPI.getEventManager().fireAttackEvent(bot, target);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing attack event: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    
    public static boolean fireDamageEvent(class_3222 bot, class_1297 attacker, float damage) {
        try {
            return PvpBotAPI.getEventManager().fireDamageEvent(bot, attacker, damage);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing damage event: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    
    public static void fireTickEvent(class_3222 bot) {
        try {
            PvpBotAPI.getEventManager().fireTickEvent(bot);
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing tick event: " + e.getMessage());

        }
    }
}
